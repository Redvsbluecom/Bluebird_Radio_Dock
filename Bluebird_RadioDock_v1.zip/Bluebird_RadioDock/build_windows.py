"""Build in a short temporary folder; publish only the portable app folder."""
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

APP_NAME = 'Bluebird_RadioDock'
SOURCE_FILES = ('Bluebird_RadioDock.py', 'luadock_ui.py', 'luadock_engine.py',
                'Bluebird_ImageDock.py', 'imagedock_core.py', 'requirements.txt',
                'test_imagedock.py', 'test_builder.py', 'build_windows.py', 'LuaDock.ico')


def copy_path(path):
    """Windows extended paths also protect the final copy to a deep folder."""
    value = os.path.abspath(path)
    if os.name != 'nt' or value.startswith('\\\\?\\'):
        return value
    if value.startswith('\\\\'):
        return '\\\\?\\UNC\\' + value[2:]
    return '\\\\?\\' + value


def publish_app(built_folder, destination):
    built_folder = Path(built_folder)
    destination = Path(destination)
    if not (built_folder / (APP_NAME + '.exe')).is_file():
        raise RuntimeError('The build did not produce the expected Windows EXE.')
    # Build products contain no downloads directory. Merge the runtime files
    # so pictures already beside an earlier executable remain untouched.
    if (built_folder / 'downloads').exists():
        raise RuntimeError('Unexpected downloads folder in the build output.')
    shutil.copytree(copy_path(built_folder), copy_path(destination), dirs_exist_ok=True)
    return destination / (APP_NAME + '.exe')


def run_step(label, command, cwd):
    print('\n' + label, flush=True)
    subprocess.run(command, cwd=cwd, check=True)


def main():
    if os.name != 'nt':
        print('This EXE builder must run on Windows.')
        return 1
    if sys.version_info < (3, 10):
        print('Python 3.10 or newer is required.')
        return 1
    source = Path(__file__).resolve().parent
    try:
        # Qt's deepest filenames no longer inherit the source folder's path.
        # A fresh environment also avoids the earlier partial installation.
        with tempfile.TemporaryDirectory(prefix='BD_') as scratch:
            work = Path(scratch)
            print('Temporary build folder: ' + str(work), flush=True)
            staged = work / 'src'
            staged.mkdir()
            for name in SOURCE_FILES:
                shutil.copyfile(source / name, staged / name)
            env = work / 'v'
            run_step('Creating a fresh private build environment...',
                     [sys.executable, '-m', 'venv', str(env)], work)
            python = str(env / 'Scripts' / 'python.exe')
            run_step('Preparing build tools...',
                     [python, '-m', 'pip', 'install', '--upgrade', 'pip'], work)
            run_step('Installing dependencies in the short build folder...',
                     [python, '-m', 'pip', 'install', '-r', str(staged / 'requirements.txt'),
                      'pyinstaller>=6.18,<7'], work)
            run_step('Checking image conversion and portable-folder publishing...',
                     [python, '-m', 'unittest', '-q', 'test_imagedock.py', 'test_builder.py'], staged)
            run_step('Checking Lua catalog and package handling...',
                     [python, str(staged / 'luadock_engine.py')], staged)
            run_step('Building the portable app...',
                     [python, '-m', 'PyInstaller', '--noconfirm', '--clean', '--onedir',
                      '--windowed', '--name', APP_NAME, '--distpath', str(work / 'dist'),
                      '--workpath', str(work / 'build'), '--specpath', str(work / 'spec'),
                      '--icon', str(staged / 'LuaDock.ico'), '--add-data', str(staged / 'LuaDock.ico') + ';.',
                      str(staged / 'Bluebird_RadioDock.py')], staged)
            output = source / 'dist' / APP_NAME
            exe = publish_app(work / 'dist' / APP_NAME, output)
            print('\nFinished: ' + str(exe), flush=True)
            print('Keep the entire app folder together. No Python or installer is needed on destination PCs.')
            try:
                os.startfile(str(output))
            except OSError:
                print('The app is built. Open the output folder manually.')
        return 0
    except subprocess.CalledProcessError as err:
        print('\nBuild stopped: the step above failed (exit ' + str(err.returncode) + ').')
        return 1
    except (OSError, RuntimeError) as err:
        print('\nBuild stopped: ' + str(err))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
