"""Portable output publishing checks, independent of the Windows build tools."""
from pathlib import Path
import tempfile
import unittest
from build_windows import APP_NAME, publish_app


class BuildTests(unittest.TestCase):
    def test_publish_preserves_saved_images(self):
        with tempfile.TemporaryDirectory() as root:
            root = Path(root)
            built = root / 'built'; built.mkdir()
            (built / (APP_NAME + '.exe')).write_bytes(b'new app')
            (built / '_internal').mkdir()
            (built / '_internal' / 'Qt6Core.dll').write_bytes(b'runtime')
            output = root / 'existing'
            images = output / 'downloads' / 'IMAGES'; images.mkdir(parents=True)
            (images / 'PA18.png').write_bytes(b'my image')
            (output / (APP_NAME + '.exe')).write_bytes(b'previous app')
            exe = publish_app(built, output)
            self.assertEqual(exe.read_bytes(), b'new app')
            self.assertEqual((images / 'PA18.png').read_bytes(), b'my image')
            self.assertEqual((output / '_internal' / 'Qt6Core.dll').read_bytes(), b'runtime')

    def test_failed_build_does_not_replace_working_app(self):
        with tempfile.TemporaryDirectory() as root:
            root = Path(root)
            built = root / 'built'; built.mkdir()
            output = root / 'existing'; output.mkdir()
            exe = output / (APP_NAME + '.exe'); exe.write_bytes(b'working app')
            with self.assertRaises(RuntimeError):
                publish_app(built, output)
            self.assertEqual(exe.read_bytes(), b'working app')


if __name__ == '__main__':
    unittest.main()
