"""Offline integration checks for combined navigation and Lua workflows."""
import io,tempfile,time,zipfile,threading,unittest
from pathlib import Path
from unittest.mock import patch
from PIL import Image
from PySide6.QtWidgets import QApplication
from Bluebird_RadioDock import RadioDock
from luadock_ui import engine


def png(color):
    buf=io.BytesIO();Image.new('RGB',(80,50),color).save(buf,'PNG');return buf.getvalue()


class Integration(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.app=QApplication.instance() or QApplication([])
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.paths=patch.object(engine,'program_directory',lambda:self.root);self.paths.start()
        self.window=RadioDock(offline=True);self.window.show();self.panel=self.window.lua
        self.window.images.settings_file=self.root/'ImageDock_settings.json'
        self.window.images.default_output=self.root/'downloads'/'IMAGES'
        self.window.images.output=self.window.images.default_output
        self.errors=[]
        self.warning=patch('luadock_ui.QMessageBox.warning',lambda *a:self.errors.append(a[-1]));self.warning.start()
    def tearDown(self):
        self.window.close();self.app.processEvents();self.paths.stop();self.warning.stop();self.temp.cleanup()
    def wait_for(self,condition):
        end=time.monotonic()+4
        while time.monotonic()<end:
            self.app.processEvents()
            if condition():return
            time.sleep(.01)
        self.fail('Asynchronous operation did not finish')
    def catalog(self):
        return [engine.CatalogItem('a','Test widget','Telemetry & Widgets','GPS telemetry','https://github.com/example/widget',('color',),('ASSETS/a.png',)),
                engine.CatalogItem('b','Mono tool','Radio Tools','Setup','https://example.com/tool',('black-and-white',)),
                engine.CatalogItem('c','Test theme','Themes','800x480 background','https://github.com/EdgeTX/themes',('color',))]
    def test_navigation_filters_selection(self):
        self.assertFalse(self.window.images.isWindow())
        self.window.image_button.click();self.assertIs(self.window.stack.currentWidget(),self.window.images)
        self.window.images.model_search.setText('Ranger');self.window.lua_button.click()
        self.assertIs(self.window.stack.currentWidget(),self.panel)
        self.assertEqual(self.window.images.model_search.text(),'Ranger')
        self.panel.items=self.catalog();self.panel.rebuild_categories();self.assertEqual(self.panel.results.count(),2)
        self.panel.select_visible();self.assertEqual(self.panel.selected_ids,{'a','c'})
        self.panel.search.setText('theme');self.assertEqual(self.panel.results.count(),1)
        self.assertEqual(self.panel.selected_ids,{'a','c'})
        self.panel.clear_selection();self.assertFalse(self.panel.selected_ids)
        self.panel.search.setText('zzzzz');self.assertEqual(self.panel.results.count(),0)
        self.assertIn('No results',self.panel.count.text());self.assertFalse(self.panel.source_button.isEnabled())
    def test_refresh_failure_keeps_cache(self):
        with patch.object(engine,'fetch_catalog',lambda:(self.catalog(),'test')):
            self.panel.refresh();self.assertTrue(self.panel.activity.isVisible());self.wait_for(lambda:not self.panel.catalog_busy)
        self.assertEqual(len(self.panel.items),3);self.assertTrue(engine.cache_path().is_file())
        with patch.object(engine,'fetch_catalog',side_effect=RuntimeError('offline')):
            self.panel.refresh();self.wait_for(lambda:not self.panel.catalog_busy)
        self.assertEqual(len(self.panel.items),3);self.assertIn('Saved catalog',self.panel.status.text())
        self.assertTrue(self.panel.refresh_button.isEnabled())
    def test_stale_preview_ignored(self):
        self.panel.preview_generation=12;self.panel.finished('preview',12,(True,png('blue')))
        self.assertFalse(self.panel.preview.pixmap().isNull())
        self.panel.finished('preview',11,(True,png('red')))
        self.assertEqual(self.panel.preview.pixmap().toImage().pixelColor(0,0).name(),'#0000ff')
    def test_download_extract_report_destination(self):
        self.panel.items=self.catalog();self.panel.rebuild_categories();self.panel.selected_ids={'a'}
        target=self.root/'chosen';target.mkdir();self.panel.set_destination(target)
        from imagedock_core import load_destination
        self.assertEqual(load_destination(self.root/'LuaDock_settings.json',self.panel.default_output),target)
        source=self.root/'sample.zip'
        with zipfile.ZipFile(source,'w') as z:z.writestr('repo/SCRIPTS/TOOLS/test.lua','return 42')
        def download(url,path,progress=None):
            path.write_bytes(source.read_bytes())
            if progress:progress(10,10)
        with patch.object(engine,'stream_download',download):
            self.panel.download_selected();self.wait_for(lambda:not self.panel.download_busy)
        self.assertTrue(list((target/'ZIPs').glob('*.zip')))
        extracted=next((target/'Programs').iterdir())
        self.assertEqual((extracted/'SCRIPTS/TOOLS/test.lua').read_text(),'return 42')
        self.assertTrue((extracted/engine.INSTALL_GUIDE_NAME).is_file())
        self.assertTrue(list(target.glob('*Manifest*.txt')));self.assertFalse(self.panel.selected_ids);self.assertFalse(self.errors)
        absent=self.root/'missing_radio';self.panel.set_destination(absent)
        self.assertFalse(self.panel.destination_ready());self.assertFalse(absent.exists())
    def test_cancel_queue_after_current(self):
        self.panel.items=self.catalog();self.panel.selected_ids={'a','c'}
        started=threading.Event();proceed=threading.Event();calls=[]
        def download(item,directory,progress):
            calls.append(item.item_id);started.set();proceed.wait(2)
            return engine.DownloadResult(item,'manual','test')
        with patch.object(engine,'download_catalog_item',download):
            self.panel.download_selected();self.wait_for(started.is_set);self.panel.cancel_downloads();proceed.set()
            self.wait_for(lambda:not self.panel.download_busy)
        self.assertEqual(calls,['a']);self.assertIn('1 cancelled',self.panel.status.text());self.assertEqual(self.panel.selected_ids,{'c'})


if __name__=='__main__':unittest.main()
