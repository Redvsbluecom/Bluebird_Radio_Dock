#!/usr/bin/env python3
"""LuaDock 1.6.0 catalog and package engine for Bluebird RadioDock.

Retains catalog discovery, themes, LED sources, safe package extraction,
non-overwriting downloads, install guides and manifests. The shared Qt UI
is in luadock_ui.py. Run this module to check the engine offline.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import io
import json
import os
import re
import shutil
import sys
import tempfile
import threading
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
import zipfile
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, dataclass
from pathlib import Path, PurePosixPath
from typing import Callable, Optional, Sequence


APP_NAME = "LuaDock for EdgeTX"
APP_VERSION = "1.6.0"
INSTALL_GUIDE_NAME = "LUADOCK_INSTALL_GUIDE.md"
MAX_MANIFESTS = 5
CATALOG_URLS = (
    "https://raw.githubusercontent.com/EdgeTX/lua-scripts/main/scripts.json",
    "https://github.com/EdgeTX/lua-scripts/raw/refs/heads/main/scripts.json",
)
CATALOG_PAGE = "https://github.com/EdgeTX/lua-scripts/blob/main/scripts.json"
USER_AGENT = f"{APP_NAME.replace(' ', '-')}/{APP_VERSION}"
NETWORK_TIMEOUT = 30
MAX_DOWNLOAD_BYTES = 500 * 1024 * 1024
MAX_EXTRACT_BYTES = 1024 * 1024 * 1024
MAX_PREVIEW_BYTES = 6 * 1024 * 1024
PREVIEW_TIMEOUT = 8
PREVIEW_BASE = "https://raw.githubusercontent.com/EdgeTX/lua-scripts/main/"
THEMES_TREE_URL = "https://api.github.com/repos/EdgeTX/themes/git/trees/main?recursive=1"
THEMES_BASE = "https://raw.githubusercontent.com/EdgeTX/themes/main/"

RADIO_PROFILES = (
    ("RadioMaster TX16S family / TX15 (Color)", "color"),
    ("RadioMaster Boxer / Pocket / TX12 / Zorro (B&W)", "black-and-white"),
    ("Jumper T15 / T16 / T18 (Color)", "color"),
    ("FlySky NV14 / EL18 / PL18 (Color)", "color"),
    ("FrSky X10 / X12S (Color)", "color"),
    ("FrSky X9 / QX7 / X-Lite (B&W)", "black-and-white"),
    ("Other EdgeTX color-screen radio", "color"),
    ("Other EdgeTX black-and-white radio", "black-and-white"),
    ("All catalog entries", "all"),
)
COMPATIBILITY_OPTIONS = tuple(label for label, _tag in RADIO_PROFILES)
PROFILE_TAGS = dict(RADIO_PROFILES)

CATEGORY_ORDER = (
    "LED Gimbals",
    "Themes",
    "Telemetry & Widgets",
    "Radio Tools",
    "GPS & Mapping",
    "Flight Controller Config",
    "Logging & Analysis",
    "Games & Fun",
    "Audio & Media",
)


@dataclass(frozen=True)
class CatalogItem:
    item_id: str
    name: str
    category: str
    description: str
    info_url: str
    tags: tuple[str, ...]
    images: tuple[str, ...] = ()
    theme_folder: str = ""
    theme_files: tuple[str, ...] = ()

    @property
    def is_color(self) -> bool:
        folded = {tag.casefold() for tag in self.tags}
        return "color" in folded or "colour" in folded

    @property
    def is_black_and_white(self) -> bool:
        folded = {tag.casefold() for tag in self.tags}
        return bool(folded & {"black-and-white", "black & white", "monochrome", "b&w", "bw"})

    @property
    def source_kind(self) -> str:
        if self.theme_folder:
            return "Theme pack"
        if github_repository(self.info_url):
            return "Automatic ZIP"
        if is_direct_zip_url(self.info_url):
            return "Automatic ZIP"
        if self.info_url:
            return "Source page"
        return "No source"


@dataclass(frozen=True)
class DownloadResult:
    item: CatalogItem
    status: str
    detail: str
    output_path: Optional[Path] = None
    extracted_path: Optional[Path] = None


def program_directory() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def asset_path(name: str) -> Path:
    """Find bundled artwork in the EXE or beside the unpackaged script."""
    return Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent)) / name


def data_directory() -> Path:
    return program_directory() / "RadioDock_Data"


def cache_path() -> Path:
    return data_directory() / "catalog_cache.json"


def preview_url(image_path: str) -> Optional[str]:
    """Resolve screenshots only from the two known EdgeTX gallery trees."""
    parts = PurePosixPath(image_path).parts
    if (not parts or parts[0] not in {"ASSETS", "THEMES"} or
            any(part in {"", ".", ".."} or "\\" in part for part in parts) or
            not image_path.lower().endswith((".png", ".jpg", ".jpeg", ".gif"))):
        return None
    if parts[0] == "THEMES" and len(parts) < 3:
        return None
    base = THEMES_BASE if parts[0] == "THEMES" else PREVIEW_BASE
    return base + "/".join(urllib.parse.quote(part) for part in parts)


def preview_bytes(image_path: str) -> bytes:
    url = preview_url(image_path)
    if not url:
        raise ValueError("This catalog image path is not supported.")
    key = hashlib.sha256(image_path.encode("utf-8")).hexdigest()
    cached = data_directory() / "previews" / f"{key}{Path(image_path).suffix.lower()}"
    if cached.is_file() and cached.stat().st_size <= MAX_PREVIEW_BYTES:
        return cached.read_bytes()
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT,
                                                   "Accept": "image/*"})
    with urllib.request.urlopen(request, timeout=PREVIEW_TIMEOUT) as response:
        data = response.read(MAX_PREVIEW_BYTES + 1)
    if len(data) > MAX_PREVIEW_BYTES:
        raise ValueError("Preview image exceeds the size limit.")
    cached.parent.mkdir(parents=True, exist_ok=True)
    temporary = cached.with_suffix(cached.suffix + ".part")
    temporary.write_bytes(data)
    temporary.replace(cached)
    return data


def default_download_directory() -> Path:
    return program_directory() / "downloads" / "LUA"


def request_bytes(url: str, timeout: int = NETWORK_TIMEOUT) -> bytes:
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": USER_AGENT,
            "Accept": "application/json, application/zip, */*",
        },
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read()


def normalize_text(value: object, fallback: str = "") -> str:
    if value is None:
        return fallback
    return str(value).strip()


def normalize_string_list(value: object) -> tuple[str, ...]:
    if isinstance(value, str):
        return tuple(part.strip() for part in re.split(r"[,;]", value) if part.strip())
    if isinstance(value, (list, tuple)):
        return tuple(str(part).strip() for part in value if str(part).strip())
    return ()


def catalog_rows(payload: object) -> list[dict]:
    if isinstance(payload, list):
        return [row for row in payload if isinstance(row, dict)]
    if isinstance(payload, dict):
        for key in ("scripts", "items", "catalog", "entries"):
            value = payload.get(key)
            if isinstance(value, list):
                return [row for row in value if isinstance(row, dict)]
    raise ValueError("The catalog did not contain a recognized script list.")


def stable_item_id(name: str, info_url: str, category: str) -> str:
    raw = "\0".join((name, info_url, category)).encode("utf-8", errors="replace")
    return hashlib.sha256(raw).hexdigest()[:20]


def parse_catalog(payload: object) -> list[CatalogItem]:
    items: list[CatalogItem] = []
    for row in catalog_rows(payload):
        name = normalize_text(row.get("name") or row.get("title"))
        if not name:
            continue
        category = normalize_text(row.get("category"), "Other")
        description = normalize_text(row.get("description") or row.get("summary"), "No description provided.")
        info_url = normalize_text(
            row.get("infourl")
            or row.get("infoUrl")
            or row.get("info_url")
            or row.get("url")
            or row.get("website")
        )
        tags = normalize_string_list(row.get("tags"))
        images = normalize_string_list(row.get("images"))
        items.append(
            CatalogItem(
                item_id=stable_item_id(name, info_url, category),
                name=name,
                category=category,
                description=description,
                info_url=info_url,
                tags=tags,
                images=images,
            )
        )
    if not items:
        raise ValueError("The catalog was valid JSON but contained no usable entries.")
    return sorted(items, key=lambda item: (category_sort_key(item.category), item.name.casefold()))


def category_sort_key(category: str) -> tuple[int, str]:
    try:
        return CATEGORY_ORDER.index(category), category.casefold()
    except ValueError:
        return len(CATEGORY_ORDER), category.casefold()


LED_SOURCES = (
    ("TX16S MK3 LED Color Pairs", "Dual-color gimbal rings and RGB switch presets for TX16S MK3 and TX15 Max.",
     "https://github.com/wawannbe/edgetx-dual-rgb-led-color"),
    ("TX16S MK3 LED Patterns", "RGB gimbal ring and switch scripts; check each script's hardware notes before use.",
     "https://github.com/deadbytefpv/edgeTXLEDS"),
    ("TX16S MK3 LED Configurator", "Touchscreen RGB gimbal profiles with color and animation settings for TX16S MK3.",
     "https://github.com/FebyKris/FK-LED-EdgeTX"),
)


def led_catalog_items() -> list[CatalogItem]:
    return [CatalogItem(stable_item_id(name, url, "LED Gimbals"), name, "LED Gimbals",
                        description + " Requires RGB LED hardware; not for non-RGB TX16S models.",
                        url, ("color", "TX16S MK3", "RGB gimbals", "LED"))
            for name, description, url in LED_SOURCES]


def parse_theme_tree(payload: object) -> list[CatalogItem]:
    """Discover individual themes from the official gallery's Git tree."""
    if not isinstance(payload, dict) or payload.get("truncated") or not isinstance(payload.get("tree"), list):
        raise ValueError("The theme gallery returned an incomplete file list.")
    folders: dict[str, set[str]] = {}
    for row in payload["tree"]:
        if not isinstance(row, dict) or row.get("type") != "blob":
            continue
        path = row.get("path")
        if not isinstance(path, str):
            continue
        parts = PurePosixPath(path).parts
        if len(parts) < 3 or parts[0] != "THEMES":
            continue
        # Keep only paths that can be safely extracted on Windows.
        if any(part in {"", ".", ".."} or re.search(r'[<>:"|?*\\\x00-\x1f]', part)
               for part in parts):
            continue
        folders.setdefault(parts[1], set()).add("/".join(parts[2:]))
    themes = []
    for folder, files in folders.items():
        if "theme.yml" not in files or len(files) > 100:
            continue
        sizes = [size for size in ("480x272", "800x480")
                 if f"background_{size}.png" in files]
        backgrounds = ", ".join(sizes) if sizes else "no radio-sized background listed"
        name = folder.replace("_", " ")
        url = f"https://github.com/EdgeTX/themes/tree/main/THEMES/{urllib.parse.quote(folder)}"
        screenshots = tuple(f"THEMES/{folder}/{file}" for file in
                            ("screenshot1.png", "screenshot2.png", "screenshot3.png", "logo.png")
                            if file in files)
        themes.append(CatalogItem(
            stable_item_id(name, url, "Themes"), name, "Themes",
            f"EdgeTX community color theme. Backgrounds: {backgrounds}. "
            "TX16S MK3 uses 800x480; earlier TX16S/T16 use 480x272.",
            url, ("color", "theme", "TX16S", "TX16S MK3"), screenshots,
            folder, tuple(sorted(files)),
        ))
    if not themes:
        raise ValueError("No installable themes were found in the gallery.")
    return sorted(themes, key=lambda item: item.name.casefold())


def fetch_catalog() -> tuple[list[CatalogItem], str]:
    errors: list[str] = []
    for url in CATALOG_URLS:
        try:
            payload = json.loads(request_bytes(url).decode("utf-8-sig"))
            items = parse_catalog(payload) + led_catalog_items()
            try:
                themes = parse_theme_tree(json.loads(request_bytes(THEMES_TREE_URL).decode("utf-8-sig")))
            except Exception:
                # Keep cached themes if GitHub's separate themes service is unavailable.
                try:
                    themes = [item for item in load_catalog_cache()[0] if item.theme_folder]
                except Exception:
                    themes = []
            items.extend(themes)
            return sorted(items, key=lambda item: (category_sort_key(item.category), item.name.casefold())), url
        except Exception as exc:  # Each official mirror gets a chance.
            errors.append(f"{url}: {exc}")
    raise RuntimeError("Unable to download the official EdgeTX catalog.\n" + "\n".join(errors))


def save_catalog_cache(items: Sequence[CatalogItem], source_url: str) -> None:
    target = cache_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    document = {
        "saved_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "source_url": source_url,
        "items": [asdict(item) for item in items],
    }
    temporary = target.with_suffix(".tmp")
    temporary.write_text(json.dumps(document, indent=2), encoding="utf-8")
    temporary.replace(target)


def load_catalog_cache() -> tuple[list[CatalogItem], str, str]:
    target = cache_path()
    document = json.loads(target.read_text(encoding="utf-8"))
    raw_items = document.get("items")
    if not isinstance(raw_items, list):
        raise ValueError("Cached catalog has no items.")
    items = []
    for row in raw_items:
        if not isinstance(row, dict):
            continue
        items.append(
            CatalogItem(
                item_id=normalize_text(row.get("item_id")),
                name=normalize_text(row.get("name")),
                category=normalize_text(row.get("category"), "Other"),
                description=normalize_text(row.get("description"), "No description provided."),
                info_url=normalize_text(row.get("info_url")),
                tags=normalize_string_list(row.get("tags")),
                images=normalize_string_list(row.get("images")),
                theme_folder=normalize_text(row.get("theme_folder")),
                theme_files=normalize_string_list(row.get("theme_files")),
            )
        )
    items = [item for item in items if item.item_id and item.name]
    if not items:
        raise ValueError("Cached catalog has no usable items.")
    return items, normalize_text(document.get("source_url")), normalize_text(document.get("saved_utc"))


def github_repository(url: str) -> Optional[tuple[str, str]]:
    if not url:
        return None
    try:
        parsed = urllib.parse.urlparse(url)
    except ValueError:
        return None
    host = (parsed.hostname or "").casefold()
    if host not in {"github.com", "www.github.com"}:
        return None
    parts = [urllib.parse.unquote(part) for part in parsed.path.split("/") if part]
    if len(parts) < 2 or parts[0].casefold() in {"features", "topics", "marketplace"}:
        return None
    owner, repository = parts[0], re.sub(r"\.git$", "", parts[1], flags=re.IGNORECASE)
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", owner) or not re.fullmatch(r"[A-Za-z0-9_.-]+", repository):
        return None
    return owner, repository


def is_direct_zip_url(url: str) -> bool:
    if not url:
        return False
    try:
        parsed = urllib.parse.urlparse(url)
    except ValueError:
        return False
    return parsed.scheme in {"http", "https"} and parsed.path.casefold().endswith(".zip")


def safe_filename(value: str, fallback: str = "EdgeTX_Lua") -> str:
    clean = re.sub(r"[<>:\"/\\|?*\x00-\x1f]", "_", value).strip(" .")
    clean = re.sub(r"\s+", " ", clean)
    return clean[:120] or fallback


def unique_output_path(directory: Path, stem: str, suffix: str) -> Path:
    candidate = directory / f"{stem}{suffix}"
    if not candidate.exists():
        return candidate
    for number in range(2, 1000):
        candidate = directory / f"{stem} ({number}){suffix}"
        if not candidate.exists():
            return candidate
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    return directory / f"{stem}_{stamp}{suffix}"


def stream_download(url: str, destination: Path, progress: Optional[Callable[[int, Optional[int]], None]] = None) -> None:
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/zip, */*"})
    temporary = destination.with_suffix(destination.suffix + ".part")
    downloaded = 0
    try:
        with urllib.request.urlopen(request, timeout=NETWORK_TIMEOUT) as response, temporary.open("wb") as output:
            total_header = response.headers.get("Content-Length")
            total = int(total_header) if total_header and total_header.isdigit() else None
            if total is not None and total > MAX_DOWNLOAD_BYTES:
                raise ValueError("Package is larger than the 500 MB safety limit.")
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                downloaded += len(block)
                if downloaded > MAX_DOWNLOAD_BYTES:
                    raise ValueError("Package exceeded the 500 MB safety limit.")
                output.write(block)
                if progress:
                    progress(downloaded, total)
        temporary.replace(destination)
    except Exception:
        if temporary.exists():
            temporary.unlink()
        raise


def write_internet_shortcut(item: CatalogItem, directory: Path) -> Path:
    path = unique_output_path(directory, safe_filename(item.name), ".url")
    path.write_text(f"[InternetShortcut]\nURL={item.info_url}\n", encoding="utf-8")
    return path


def extract_package(archive_path: Path, programs_directory: Path,
                    package_name: str, strip_common_root: bool = False) -> Path:
    """Unpack one ZIP into its own named folder, never over existing files."""
    programs_directory.mkdir(parents=True, exist_ok=True)
    destination = unique_output_path(programs_directory, safe_filename(package_name), "")
    staging = Path(tempfile.mkdtemp(prefix=".lua_unpack_", dir=programs_directory))
    try:
        with zipfile.ZipFile(archive_path) as archive:
            members = [info for info in archive.infolist() if not info.is_dir()]
            if len(members) > 30000 or sum(info.file_size for info in members) > MAX_EXTRACT_BYTES:
                raise ValueError("Package has too many files or exceeds the extraction limit.")
            paths = []
            for info in members:
                name = info.filename
                parts = PurePosixPath(name).parts
                if (not parts or name.startswith("/") or "\\" in name or
                        any(part in {".", ".."} or re.search(r'[<>:"|?*\\\x00-\x1f]', part)
                            for part in parts) or
                        ((info.external_attr >> 16) & 0o170000) == 0o120000):
                    raise ValueError(f"Unsafe filename in ZIP: {name}")
                paths.append(parts)
            # GitHub zipball files all share a generated repository root.
            strip_root = strip_common_root and bool(paths) and all(
                len(parts) > 1 and parts[0] == paths[0][0] for parts in paths)
            seen = set()
            for info, parts in zip(members, paths):
                relative = Path(*(parts[1:] if strip_root else parts))
                folded = str(relative).casefold()
                if folded in seen:
                    raise ValueError(f"Conflicting filenames in ZIP: {relative}")
                seen.add(folded)
                target = staging / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(info) as source, target.open("xb") as output:
                    shutil.copyfileobj(source, output, 1024 * 1024)
        staging.replace(destination)
        return destination
    except Exception:
        shutil.rmtree(staging, ignore_errors=True)
        raise


def install_locations(item: CatalogItem, extracted: Path) -> list[tuple[str, str]]:
    """Suggest destinations only where the package already follows EdgeTX layout."""
    if item.theme_folder and (extracted / "theme.yml").is_file():
        return [(".", f"/THEMES/{item.theme_folder}/")]
    locations: set[tuple[str, str]] = set()
    ignored_roots = {"example", "examples", "demo", "demos", "test", "tests", "template", "templates"}
    for file in extracted.rglob("*"):
        if not file.is_file() or file.name == INSTALL_GUIDE_NAME:
            continue
        parts = file.relative_to(extracted).parts
        for index, part in enumerate(parts[:-1]):
            if any(previous.casefold() in ignored_roots for previous in parts[:index]):
                continue
            if part.casefold() == "widgets" and len(parts) > index + 2:
                widget = parts[index + 1]
                source = Path(*parts[:index + 2]).as_posix()
                locations.add((source, f"/WIDGETS/{widget}/"))
                break
            if part.casefold() == "themes" and len(parts) > index + 2:
                theme = parts[index + 1]
                source = Path(*parts[:index + 2]).as_posix()
                locations.add((source, f"/THEMES/{theme}/"))
                break
            if part.casefold() == "scripts" and len(parts) > index + 2:
                kind = parts[index + 1]
                if kind.casefold() in {"tools", "functions", "rgbled", "mixes", "telemetry"}:
                    source = Path(*parts[:index + 2]).as_posix()
                    locations.add((source, f"/SCRIPTS/{kind}/"))
                    break
    return sorted(locations, key=lambda pair: (pair[1].casefold(), pair[0].casefold()))


def write_install_guide(item: CatalogItem, extracted: Path) -> Path:
    """Explain observed paths without moving files or guessing unstructured layouts."""
    paths = install_locations(item, extracted)
    readmes = sorted((file.relative_to(extracted).as_posix() for file in extracted.rglob("*")
                      if file.is_file() and file.name.casefold() in
                      {"readme", "readme.md", "readme.txt", "install.md", "installation.md"}),
                     key=lambda name: (name.count("/"), name.casefold()))[:8]
    lua_files = sorted((file.relative_to(extracted).as_posix() for file in extracted.rglob("*")
                        if file.is_file() and file.suffix.casefold() == ".lua"), key=str.casefold)
    lines = [
        f"# LuaDock install guide: {item.name}", "",
        f"Publisher: {item.info_url or 'Not listed'}", "",
        "This guide describes paths found inside the downloaded package. Check the publisher's",
        "instructions and your radio model before copying files. LuaDock has not changed your SD card.", "",
    ]
    if readmes:
        lines.extend(["## Publisher instructions", ""])
        lines.extend(f"- `{name}`" for name in readmes)
        lines.append("")
    if paths:
        lines.extend(["## Paths found in this package", "",
                      "Copy the contents of each source folder to the matching destination on the SD card,",
                      "keeping its subfolders. Choose the correct radio variant if the publisher supplies several.", ""])
        lines.extend(f"- `{source}/` → `{destination}`" for source, destination in paths)
        lines.append("")
    else:
        lines.extend(["## Placement needs publisher instructions", "",
                      "This package does not expose a recognizable EdgeTX install layout.",
                      "Do not assume every Lua file belongs in SCRIPTS/TOOLS. Check the publisher's README.", ""])
        if lua_files:
            lines.extend(["Lua files found (first 12):", ""])
            lines.extend(f"- `{name}`" for name in lua_files[:12])
            lines.append("")
    if any(target.upper().startswith("/SCRIPTS/RGBLED/") for _, target in paths) or item.category == "LED Gimbals":
        lines.extend(["## RGB LED hardware", "",
                      "LED scripts require a radio with supported RGB hardware. Follow the publisher's",
                      "setup for the RGB LED Special Function and check that it supports your radio.", ""])
    if any(target.upper().startswith("/WIDGETS/") for _, target in paths):
        lines.extend(["Widget folders appear in the radio's Widgets selection menu on color screens.", ""])
    if any(target.upper().startswith("/SCRIPTS/TOOLS/") for _, target in paths):
        lines.extend(["Tool scripts appear in the radio's Apps/Tools menu.", ""])
    if any(target.upper().startswith("/SCRIPTS/FUNCTIONS/") for _, target in paths):
        lines.extend(["Function scripts are enabled from Special Functions after copying.", ""])
    if item.theme_folder or any(target.upper().startswith("/THEMES/") for _, target in paths):
        lines.extend(["Themes are selected in Radio Settings > Themes on color-screen radios.",
                      "TX16S MK3 uses 800x480 backgrounds; older TX16S/T16 models use 480x272.", ""])
    guide = extracted / INSTALL_GUIDE_NAME
    guide.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")
    return guide


def install_guide_detail(item: CatalogItem, extracted: Path) -> str:
    try:
        write_install_guide(item, extracted)
    except OSError as exc:
        return f"; install guide unavailable: {exc}"
    return f"; open {INSTALL_GUIDE_NAME} in the extracted folder"


def download_theme(item: CatalogItem, directory: Path,
                   progress: Optional[Callable[[int, Optional[int]], None]] = None) -> DownloadResult:
    """Save one complete theme, avoiding a download of the entire gallery."""
    if (not item.theme_files or item.theme_folder != safe_filename(item.theme_folder) or
            "/" in item.theme_folder or "\\" in item.theme_folder):
        return DownloadResult(item, "failed", "Invalid theme folder in the catalog.")
    zip_dir = directory / "ZIPs"
    zip_dir.mkdir(parents=True, exist_ok=True)
    destination = unique_output_path(zip_dir, safe_filename(item.name), ".zip")
    total = 0
    try:
        with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as archive:
            for relative in item.theme_files:
                parts = PurePosixPath(relative).parts
                if (not parts or any(part in {"", ".", ".."} or
                        re.search(r'[<>:"|?*\\\x00-\x1f]', part) for part in parts)):
                    raise ValueError("Invalid theme file path in the gallery.")
                url = THEMES_BASE + "/".join(urllib.parse.quote(part) for part in
                                              ("THEMES", item.theme_folder, *parts))
                request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
                with urllib.request.urlopen(request, timeout=NETWORK_TIMEOUT) as response:
                    data = response.read(12 * 1024 * 1024 + 1)
                total += len(data)
                if len(data) > 12 * 1024 * 1024 or total > 64 * 1024 * 1024:
                    raise ValueError("Theme exceeds the download size limit.")
                archive.writestr("/".join((item.theme_folder, *parts)), data)
                if progress:
                    progress(total, None)
        unpacked = extract_package(destination, directory / "Themes", item.theme_folder,
                                   strip_common_root=True)
        return DownloadResult(item, "downloaded", "Downloaded theme; unpacked into Themes for review" +
                              install_guide_detail(item, unpacked),
                              destination, unpacked)
    except Exception as exc:
        # A partial ZIP is not a usable saved copy and must not suppress later retries.
        destination.unlink(missing_ok=True)
        return DownloadResult(item, "failed", str(exc))


def download_catalog_item(
    item: CatalogItem,
    directory: Path,
    progress: Optional[Callable[[int, Optional[int]], None]] = None,
) -> DownloadResult:
    directory.mkdir(parents=True, exist_ok=True)
    if item.theme_folder:
        return download_theme(item, directory, progress)
    repository = github_repository(item.info_url)
    try:
        if repository:
            owner, repo = repository
            url = f"https://api.github.com/repos/{urllib.parse.quote(owner)}/{urllib.parse.quote(repo)}/zipball"
            zip_dir = directory / "ZIPs"
            zip_dir.mkdir(parents=True, exist_ok=True)
            destination = unique_output_path(zip_dir, safe_filename(item.name), ".zip")
            stream_download(url, destination, progress)
            if not zipfile.is_zipfile(destination):
                destination.unlink(missing_ok=True)
                raise ValueError("GitHub did not return a valid ZIP archive.")
            unpacked = extract_package(destination, directory / "Programs", item.name,
                                       strip_common_root=True)
            return DownloadResult(item, "downloaded", f"Downloaded {owner}/{repo}; extracted for review" +
                                  install_guide_detail(item, unpacked),
                                  destination, unpacked)
        if is_direct_zip_url(item.info_url):
            zip_dir = directory / "ZIPs"
            zip_dir.mkdir(parents=True, exist_ok=True)
            destination = unique_output_path(zip_dir, safe_filename(item.name), ".zip")
            stream_download(item.info_url, destination, progress)
            if not zipfile.is_zipfile(destination):
                destination.unlink(missing_ok=True)
                raise ValueError("The publisher did not return a valid ZIP archive.")
            unpacked = extract_package(destination, directory / "Programs", item.name)
            return DownloadResult(item, "downloaded", "Downloaded direct ZIP; extracted for review" +
                                  install_guide_detail(item, unpacked),
                                  destination, unpacked)
        if item.info_url:
            link_dir = directory / "Links"
            link_dir.mkdir(parents=True, exist_ok=True)
            shortcut = write_internet_shortcut(item, link_dir)
            return DownloadResult(item, "manual", "Publisher link saved", shortcut)
        return DownloadResult(item, "skipped", "No source URL is listed")
    except Exception as exc:
        saved_zip = destination if "destination" in locals() and destination.is_file() else None
        detail = f"{exc} (ZIP retained in ZIPs for review)" if saved_zip else str(exc)
        return DownloadResult(item, "failed", detail, saved_zip)


def existing_downloads(item: CatalogItem, directory: Path) -> list[Path]:
    """Find saved copies from this or earlier runs without an extra index file."""
    stem = safe_filename(item.name)
    matches = []
    for folder, suffix in (("ZIPs", ".zip"), ("Programs", ""), ("Links", ".url"),
                           ("Themes", "")):
        location = directory / folder
        if not location.is_dir():
            continue
        pattern = re.compile(rf"^{re.escape(stem)}(?: \(\d+\))?{re.escape(suffix)}$", re.IGNORECASE)
        matches.extend(path for path in location.iterdir() if pattern.fullmatch(path.name))
    return matches


def confirm_repeat_downloads(items: Sequence[CatalogItem], directory: Path, messagebox) -> list[CatalogItem]:
    approved = []
    for item in items:
        copies = existing_downloads(item, directory)
        if copies and not messagebox.askyesno(
            "Already Downloaded",
            f"{item.name} already has saved files in this download folder.\n\n"
            "The catalog does not list a release version, so this could be the same copy or a newer one.\n\n"
            "Download another copy?",
            default=messagebox.NO,
        ):
            continue
        approved.append(item)
    return approved


def write_manifest(results: Sequence[DownloadResult], directory: Path) -> Path:
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    path = unique_output_path(directory, f"EdgeTX_Lua_Download_Manifest_{stamp}", ".txt")
    lines = [
        f"{APP_NAME} {APP_VERSION}",
        f"Created: {dt.datetime.now().astimezone().isoformat(timespec='seconds')}",
        f"Folder: {directory}",
        "",
        "This app downloads packages only. It does not install or modify an SD card.",
        "",
    ]
    for result in results:
        output = str(result.output_path) if result.output_path else "(none)"
        guide = result.extracted_path / INSTALL_GUIDE_NAME if result.extracted_path else None
        lines.extend(
            [
                f"[{result.status.upper()}] {result.item.name}",
                f"Category: {result.item.category}",
                f"Source: {result.item.info_url or '(not provided)'}",
                f"Result: {result.detail}",
                f"Saved: {output}",
                f"Extracted: {result.extracted_path or '(none)'}",
                f"Install guide: {guide if guide and guide.is_file() else '(none)'}",
                "",
            ]
        )
    path.write_text("\n".join(lines), encoding="utf-8")
    reports = sorted(directory.glob("EdgeTX_Lua_Download_Manifest_*.txt"),
                     key=lambda report: (report.stat().st_mtime_ns, report.name), reverse=True)
    for old_report in reports[MAX_MANIFESTS:]:
        try:
            old_report.unlink()
        except OSError:
            pass  # A locked report must not cancel a completed download.
    return path


def human_bytes(value: int) -> str:
    units = ("B", "KB", "MB", "GB")
    amount = float(value)
    for unit in units:
        if amount < 1024 or unit == units[-1]:
            return f"{amount:.1f} {unit}" if unit != "B" else f"{int(amount)} B"
        amount /= 1024
    return f"{value} B"


def open_directory(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    if sys.platform.startswith("win"):
        os.startfile(path)  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        import subprocess

        subprocess.Popen(["open", str(path)])
    else:
        import subprocess

        subprocess.Popen(["xdg-open", str(path)])


def run_self_test() -> None:
    from PIL import Image

    thumbnail = Image.new("RGB", (20, 10), "blue")
    bitmap = io.BytesIO()
    thumbnail.save(bitmap, format="JPEG")
    with Image.open(io.BytesIO(bitmap.getvalue())) as decoded:
        assert decoded.size == (20, 10)
    sample = {
        "scripts": [
            {
                "name": "Test Widget",
                "category": "Telemetry & Widgets",
                "description": "Test description",
                "infourl": "https://github.com/example/project/releases",
                "tags": ["color", "telemetry"],
                "images": ["preview.png"],
            },
            {
                "name": "Manual Tool",
                "category": "Radio Tools",
                "infourl": "https://example.com/tool",
                "tags": "color; tool",
            },
            {
                "name": "Mono Tool",
                "category": "Radio Tools",
                "infourl": "https://example.com/mono",
                "tags": ["black-and-white", "script"],
            },
        ]
    }
    items = parse_catalog(sample)
    assert len(items) == 3
    assert items[0].is_color
    assert github_repository(items[0].info_url) == ("example", "project")
    assert items[0].source_kind == "Automatic ZIP"
    manual = next(item for item in items if item.name == "Manual Tool")
    mono = next(item for item in items if item.name == "Mono Tool")
    assert manual.source_kind == "Source page"
    assert mono.is_black_and_white
    assert safe_filename('Bad:Name/Here*') == "Bad_Name_Here_"
    assert preview_url("ASSETS/test/screenshot-1.png") == (
        PREVIEW_BASE + "ASSETS/test/screenshot-1.png")
    assert preview_url("ASSETS/../unsafe.png") is None
    assert preview_url("THEMES/Blue/screenshot1.png") == THEMES_BASE + "THEMES/Blue/screenshot1.png"
    assert preview_url("THEMES/../screenshot1.png") is None
    assert len(led_catalog_items()) == 3
    tree = {"tree": [
        {"type": "blob", "path": "THEMES/Blue/theme.yml"},
        {"type": "blob", "path": "THEMES/Blue/logo.png"},
        {"type": "blob", "path": "THEMES/Blue/screenshot1.png"},
        {"type": "blob", "path": "THEMES/Blue/background_800x480.png"},
        {"type": "blob", "path": "THEMES/Incomplete/logo.png"},
        {"type": "blob", "path": "THEMES/Blue/../bad.png"},
    ]}
    theme = parse_theme_tree(tree)[0]
    assert theme.theme_folder == "Blue" and theme.source_kind == "Theme pack"
    assert len(theme.theme_files) == 4 and len(theme.images) == 2
    with tempfile.TemporaryDirectory() as temporary:
        directory = Path(temporary)
        shortcut = write_internet_shortcut(manual, directory)
        assert shortcut.read_text(encoding="utf-8").startswith("[InternetShortcut]")
        result = DownloadResult(manual, "manual", "Publisher link saved", shortcut)
        manifest = write_manifest([result], directory)
        assert "Manual Tool" in manifest.read_text(encoding="utf-8")
        unrelated = directory / "my_notes.txt"
        unrelated.write_text("keep", encoding="utf-8")
        for _ in range(MAX_MANIFESTS + 2):
            manifest = write_manifest([result], directory)
        assert len(list(directory.glob("EdgeTX_Lua_Download_Manifest_*.txt"))) == MAX_MANIFESTS
        assert manifest.is_file() and unrelated.read_text(encoding="utf-8") == "keep"
        sample_zip = directory / "sample.zip"
        with zipfile.ZipFile(sample_zip, "w") as archive:
            archive.writestr("repo-hash/SCRIPTS/TOOLS/test.lua", b"return 42\n")
            archive.writestr("repo-hash/README.md", b"Test project\n")
        first = extract_package(sample_zip, directory / "Programs", "Test Widget",
                                strip_common_root=True)
        second = extract_package(sample_zip, directory / "Programs", "Test Widget",
                                 strip_common_root=True)
        assert (first / "SCRIPTS/TOOLS/test.lua").read_bytes() == b"return 42\n"
        assert first != second and second.is_dir()
        original_stream_download = globals()["stream_download"]
        try:
            globals()["stream_download"] = lambda _url, target, _progress=None: shutil.copyfile(sample_zip, target)
            downloaded = download_catalog_item(items[0], directory / "Unified Downloads")
        finally:
            globals()["stream_download"] = original_stream_download
        assert downloaded.status == "downloaded"
        assert downloaded.output_path.parent.name == "ZIPs"
        assert downloaded.extracted_path.parent.name == "Programs"
        assert (downloaded.extracted_path / "SCRIPTS/TOOLS/test.lua").is_file()
        guide = downloaded.extracted_path / INSTALL_GUIDE_NAME
        assert "`SCRIPTS/TOOLS/` → `/SCRIPTS/TOOLS/`" in guide.read_text(encoding="utf-8")
        assert "README.md" in guide.read_text(encoding="utf-8")
        assert not (directory / "SCRIPTS").exists()
        unknown = directory / "Unstructured"
        unknown.mkdir()
        (unknown / "custom.lua").write_text("return {}", encoding="utf-8")
        unknown_guide = write_install_guide(items[0], unknown).read_text(encoding="utf-8")
        assert "Placement needs publisher instructions" in unknown_guide
        assert "custom.lua" in unknown_guide and "Copy the contents" not in unknown_guide
        widget = directory / "Widget"
        (widget / "release" / "WIDGETS" / "MYWGT").mkdir(parents=True)
        (widget / "release" / "WIDGETS" / "MYWGT" / "main.lua").write_text("return {}", encoding="utf-8")
        assert ("release/WIDGETS/MYWGT", "/WIDGETS/MYWGT/") in install_locations(items[0], widget)
        assert downloaded.output_path in existing_downloads(items[0], directory / "Unified Downloads")
        assert not existing_downloads(mono, directory / "Unified Downloads")
        class RepeatPrompt:
            NO = "no"

            def __init__(self, answer):
                self.answer = answer
                self.asked = []

            def askyesno(self, _title, message, **_options):
                self.asked.append(message)
                return self.answer

        decline = RepeatPrompt(False)
        assert confirm_repeat_downloads([items[0], mono], directory / "Unified Downloads", decline) == [mono]
        assert len(decline.asked) == 1
        accept = RepeatPrompt(True)
        assert confirm_repeat_downloads([items[0]], directory / "Unified Downloads", accept) == [items[0]]
        from unittest.mock import patch

        with patch("urllib.request.urlopen", side_effect=lambda *_args, **_kwargs: io.BytesIO(b"sample theme data")):
            theme_result = download_catalog_item(theme, directory / "Unified Downloads")
        assert theme_result.status == "downloaded"
        assert (theme_result.extracted_path / "theme.yml").read_bytes() == b"sample theme data"
        assert theme_result.extracted_path.parent.name == "Themes"
        assert theme_result.output_path in existing_downloads(theme, directory / "Unified Downloads")
        theme_guide = (theme_result.extracted_path / INSTALL_GUIDE_NAME).read_text(encoding="utf-8")
        assert "`./` → `/THEMES/Blue/`" in theme_guide
        linked = download_catalog_item(manual, directory / "Unified Downloads")
        assert linked.status == "manual" and linked.output_path.parent.name == "Links"
        unsafe_zip = directory / "unsafe.zip"
        with zipfile.ZipFile(unsafe_zip, "w") as archive:
            archive.writestr("../outside.lua", b"unsafe")
        try:
            extract_package(unsafe_zip, directory / "Programs", "Unsafe")
        except ValueError:
            pass
        else:
            raise AssertionError("Unsafe archive path was not rejected")
        assert not (directory / "outside.lua").exists()
    print("LuaDock engine self-test passed.")


if __name__ == "__main__":
    run_self_test()
