"""Image conversion and filename handling; usable without the GUI."""
from pathlib import Path
import csv
import io
import json
import re
import struct
import unicodedata
from datetime import datetime, timezone
from PIL import Image, ImageOps

PROFILES = {
    'Color model icon — 192 × 114 PNG': (192, 114, 'PNG'),
    'Monochrome model icon — 64 × 32 BMP': (64, 32, 'BMP'),
}
Image.MAX_IMAGE_PIXELS = 20_000_000
MAX_BYTES = 20 * 1024 * 1024


def convert_image(data, profile, background='Transparent'):
    if len(data) > MAX_BYTES:
        raise ValueError('Image exceeds the 20 MB limit.')
    w, h, fmt = PROFILES[profile]
    with Image.open(io.BytesIO(data)) as original:
        if original.width * original.height > Image.MAX_IMAGE_PIXELS:
            raise ValueError('Image exceeds the 20 megapixel limit.')
        image = ImageOps.exif_transpose(original).convert('RGBA')
        image.thumbnail((w, h), Image.Resampling.LANCZOS)
        color = {'Transparent': (0, 0, 0, 0), 'White': (255, 255, 255, 255),
                 'Black': (0, 0, 0, 255)}[background]
        if fmt == 'BMP' and background == 'Transparent':
            color = (255, 255, 255, 255)
        canvas = Image.new('RGBA', (w, h), color)
        canvas.alpha_composite(image, ((w-image.width)//2, (h-image.height)//2))
        if fmt == 'BMP':
            return bmp4(canvas.convert('L')), 'bmp'
        output = io.BytesIO()
        canvas.save(output, format=fmt)
        return output.getvalue(), fmt.lower()


def bmp4(image):
    """Uncompressed 4-bit indexed BMP with a 16-level gray palette."""
    w, h = image.size
    stride = ((w * 4 + 31) // 32) * 4
    pixels = bytearray()
    for y in range(h-1, -1, -1):
        row = bytearray()
        for x in range(0, w, 2):
            left = (image.getpixel((x, y)) + 8) // 17
            right = (image.getpixel((x+1, y)) + 8) // 17 if x+1 < w else 0
            row.append((left << 4) | right)
        pixels.extend(row + bytes(stride-len(row)))
    offset = 14 + 40 + 16*4
    header = struct.pack('<2sIHHI', b'BM', offset+len(pixels), 0, 0, offset)
    dib = struct.pack('<IiiHHIIiiII', 40, w, h, 1, 4, 0, len(pixels), 2835, 2835, 16, 16)
    palette = b''.join(bytes((v*17, v*17, v*17, 0)) for v in range(16))
    return header + dib + palette + pixels


def short_name(name):
    name = unicodedata.normalize('NFKD', name).encode('ascii', 'ignore').decode()
    name = re.sub(r'[^A-Za-z0-9]', '', name)[:9] or 'model'
    if name.upper() in {'CON', 'PRN', 'AUX', 'NUL', *('COM'+str(i) for i in range(1,10)),
                        *('LPT'+str(i) for i in range(1,10))}:
        name = 'm'+name
    return name[:9]


def load_destination(settings_file, default):
    """Keep a missing removable destination selected so saves cannot go elsewhere."""
    try:
        value = json.loads(Path(settings_file).read_text(encoding='utf-8')).get('destination')
        if isinstance(value, str) and value and Path(value).is_absolute():
            return Path(value)
    except (OSError, ValueError, AttributeError):
        pass
    return Path(default)


def store_destination(settings_file, destination):
    settings_file = Path(settings_file)
    temporary = settings_file.with_suffix('.tmp')
    temporary.write_text(json.dumps({'destination': str(destination) if destination is not None else None}, indent=2), encoding='utf-8')
    temporary.replace(settings_file)


def check_destination(folder):
    if not Path(folder).is_dir():
        raise OSError('Destination folder is unavailable. Reconnect the radio / SD card or choose another download folder.')


def save_unique(folder, name, data, extension, require_existing=False):
    """Exclusive creation also protects case-insensitive SD card filenames."""
    folder = Path(folder)
    if require_existing:
        check_destination(folder)
    else:
        folder.mkdir(parents=True, exist_ok=True)
    existing = {p.name.casefold() for p in folder.iterdir()}
    base = short_name(name)
    for n in range(10000):
        suffix = str(n) if n else ''
        candidate = folder / (base[:9-len(suffix)] + suffix + '.' + extension)
        if candidate.name.casefold() in existing:
            continue
        created = False
        try:
            with candidate.open('xb') as out:
                created = True
                out.write(data)
            return candidate
        except FileExistsError:
            continue
        except Exception:
            if created:
                candidate.unlink(missing_ok=True)
            raise
    raise ValueError('Too many matching filenames; choose another image name.')


def record_save(folder, filename, model, source, profile):
    # A source map sits alongside IMAGES, so the radio's image folder stays clean.
    report = Path(folder).parent / 'ImageDock_downloads.csv'
    fields = ['saved_utc', 'filename', 'model', 'source', 'profile']
    exists = report.exists() and report.stat().st_size > 0
    with report.open('a', newline='', encoding='utf-8') as out:
        writer = csv.writer(out)
        if not exists:
            writer.writerow(fields)
        row = [datetime.now(timezone.utc).isoformat(), filename, model, source, profile]
        # Keep page titles from becoming spreadsheet formulas in the source map.
        writer.writerow(["'"+x if x.startswith(('=', '+', '-', '@')) else x for x in row])
