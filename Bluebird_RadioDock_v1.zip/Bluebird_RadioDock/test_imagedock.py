"""Run: python -m unittest -v test_imagedock.py"""
import io
import struct
import tempfile
import unittest
from pathlib import Path
from PIL import Image
from imagedock_core import (PROFILES, convert_image, save_unique, short_name, record_save, MAX_BYTES,
                           load_destination, store_destination)


def source(size=(400, 100), color=(255, 0, 0, 255)):
    out = io.BytesIO()
    Image.new('RGBA', size, color).save(out, 'PNG')
    return out.getvalue()


class ImageTests(unittest.TestCase):
    def test_destination_remember_exact_folder_and_disconnection(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            settings = root / 'ImageDock_settings.json'
            default = root / 'app' / 'downloads' / 'IMAGES'
            chosen = root / 'radio' / 'My Pictures'
            chosen.mkdir(parents=True)
            store_destination(settings, chosen)
            restored = load_destination(settings, default)
            self.assertEqual(restored, chosen)
            saved = save_unique(restored, 'Cub', b'image', 'png', require_existing=True)
            self.assertEqual(saved.parent, chosen)
            self.assertFalse((chosen / 'IMAGES').exists())
            saved.unlink(); chosen.rmdir()
            self.assertEqual(load_destination(settings, default), chosen)
            with self.assertRaisesRegex(OSError, 'Reconnect'):
                save_unique(chosen, 'Cub', b'image', 'png', require_existing=True)
            self.assertFalse(chosen.exists())
            store_destination(settings, None)
            moved_default = root / 'moved_app' / 'downloads' / 'IMAGES'
            self.assertEqual(load_destination(settings, moved_default), moved_default)
            settings.write_text('broken settings')
            self.assertEqual(load_destination(settings, default), default)

    def test_color_aspect_and_transparency(self):
        data, extension = convert_image(source(), next(iter(PROFILES)))
        image = Image.open(io.BytesIO(data))
        self.assertEqual(image.size, (192, 114))
        self.assertEqual(extension, 'png')
        self.assertEqual(image.getpixel((0, 0))[3], 0)
        self.assertEqual(image.getpixel((96, 57)), (255, 0, 0, 255))
        self.assertEqual(image.getbbox(), (0, 33, 192, 81))

    def test_transparent_pixels_white(self):
        data, _ = convert_image(source(color=(0,0,0,0)), next(iter(PROFILES)), 'White')
        self.assertEqual(Image.open(io.BytesIO(data)).getpixel((96,57)), (255,255,255,255))

    def test_portrait_fits_without_crop(self):
        data, _ = convert_image(source((100,400)), next(iter(PROFILES)))
        self.assertEqual(Image.open(io.BytesIO(data)).getbbox(), (82,0,110,114))

    def test_monochrome_four_bit_bmp(self):
        data, ext = convert_image(source(), list(PROFILES)[1])
        self.assertEqual(data[:2], b'BM')
        self.assertEqual(ext, 'bmp')
        self.assertEqual(struct.unpack_from('<H', data, 28)[0], 4)
        self.assertEqual(struct.unpack_from('<I', data, 30)[0], 0)
        image = Image.open(io.BytesIO(data))
        self.assertEqual(image.size, (64,32))
        self.assertEqual(image.convert('RGB').getpixel((0,0)), (255,255,255))

    def test_names(self):
        self.assertEqual(short_name('../../PA-18 Super Cub'), 'PA18Super')
        self.assertEqual(short_name('CON'), 'mCON')
        self.assertEqual(short_name('***'), 'model')

    def test_collision_existing_untouched(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder/'PA18.png').write_bytes(b'original')
            first = save_unique(folder, 'pa18', b'new1', 'png')
            second = save_unique(folder, 'pa18', b'new2', 'png')
            self.assertNotEqual(first, second)
            self.assertEqual((folder/'PA18.png').read_bytes(), b'original')
            self.assertEqual(first.read_bytes(), b'new1')
            self.assertTrue(all(len(p.stem)<=9 for p in folder.iterdir()))

    def test_invalid_image_and_size_limit(self):
        with self.assertRaises(Exception):
            convert_image(b'<html>Forbidden</html>', next(iter(PROFILES)))
        with self.assertRaises(ValueError):
            convert_image(b'0'*(MAX_BYTES+1), next(iter(PROFILES)))

    def test_report_outside_images(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp)/'IMAGES'; folder.mkdir()
            record_save(folder, 'plane.png', '=formula', 'https://example.org/p.png', next(iter(PROFILES)))
            record_save(folder, 'plane1.png', 'Plane', 'https://example.org/p.png', next(iter(PROFILES)))
            report=(Path(tmp)/'ImageDock_downloads.csv').read_text()
            self.assertEqual(report.count('saved_utc'), 1)
            self.assertIn("'=formula",report)
            self.assertEqual(list(folder.iterdir()), [])


if __name__ == '__main__':
    unittest.main()
