"""Bluebird ImageDock — browse, collect, and convert EdgeTX model pictures."""
import json
import sys
import tempfile
import uuid
import time
from collections import deque
from pathlib import Path
from urllib.parse import urlsplit

from PySide6.QtCore import Qt, QUrl, QTimer
from PySide6.QtGui import QDesktopServices, QPixmap
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
    QHBoxLayout, QLabel, QPushButton, QLineEdit, QComboBox, QSplitter, QListWidget,
    QListWidgetItem, QFileDialog, QMessageBox, QCheckBox, QProgressBar, QDialog, QStackedWidget)
from PySide6.QtWebEngineCore import QWebEngineProfile, QWebEnginePage, QWebEngineDownloadRequest
from PySide6.QtWebEngineWidgets import QWebEngineView
from imagedock_core import (PROFILES, MAX_BYTES, convert_image, save_unique, record_save,
                           load_destination, store_destination, check_destination)

SOURCES = {'SkyRaccoon': 'https://www.skyraccoon.com/', 'AIR-RC': 'https://www.air-rc.com/'}
SEARCH_TIMEOUT_SECONDS = 10

# Drive the website's observed InstantSearch input and submit button, then
# wait for its result list to change and settle. No private search API is used.
SEARCH_START_JS = r'''((query, token) => {
 const input = document.querySelector('input.ais-SearchBox-input[type="search"]');
 const hits = document.querySelector('.ais-Hits');
 if (!input || !hits || !hits.querySelector('.ais-Hits-item')) return JSON.stringify({waiting:true});
 if (window.__bluebirdImageDockSearch) window.__bluebirdImageDockSearch.observer.disconnect();
 const state = {token, query, changed:false, lastChanged:0};
 state.observer = new MutationObserver(() => { state.changed=true; state.lastChanged=Date.now(); });
 state.observer.observe(hits, {childList:true, subtree:true, characterData:true, attributes:true});
 window.__bluebirdImageDockSearch = state;
 Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(input, query);
 input.dispatchEvent(new Event('input', {bubbles:true}));
 const submit = input.closest('form').querySelector('button[type="submit"]');
 if (submit) submit.click();
 return JSON.stringify({started:true});
})'''

SEARCH_POLL_JS = r'''(() => {
 const state = window.__bluebirdImageDockSearch;
 if (!state) return JSON.stringify({});
 const input = document.querySelector('input.ais-SearchBox-input[type="search"]');
 const loading = document.querySelector('.ais-SearchBox-loadingIndicator');
 return JSON.stringify({token:state.token, ready:state.changed && Date.now()-state.lastChanged>=800 &&
    input && input.value===state.query && (!loading || loading.hidden)});
})()'''

# Inspect actual links in the loaded page, including collapsed icon panels.
# This deliberately avoids invented APIs, numeric URL guessing, or crawling.
SCAN_JS = r'''(() => {
 const found = [], seen = new Set();
 const radioSite = /(^|\.)(skyraccoon|air-rc)\.com$/.test(location.hostname);
 const heading = document.querySelector('h1');
 function add(url, label, kind) {
   try {
     url = new URL(url, location.href).href;
     if (!/^https?:/.test(url) || seen.has(url)) return;
     if (!/\.(png|bmp|jpg|jpeg|webp)(\?|$)/i.test(url)) return;
     if (radioSite && !url.includes('/airicons/')) return;
     seen.add(url);
     found.push({url, label: label.slice(0,180), kind});
   } catch(e) {}
 }
 for (const a of document.querySelectorAll('a[href]')) {
   const box = a.closest('li');
   const model = heading ? heading.textContent.trim() :
     (box ? box.textContent.trim().replace(/\s+/g,' ').split(/X20 BMP|X18 BMP|Horus|Other/)[0] : '');
   const label = model || a.textContent.trim() || a.getAttribute('href').split('/').pop();
   add(a.href, label, 'link');
 }
 if (!radioSite) {
   for (const img of document.images) {
     if (img.naturalWidth < 40 || img.naturalHeight < 25) continue;
     add(img.currentSrc || img.src, img.alt || (heading && heading.textContent.trim()) || 'Image', 'image');
   }
 }
 return JSON.stringify(found);
})()'''


class Dock(QMainWindow):
    def __init__(self, offline=False):
        super().__init__()
        self.setWindowTitle('Bluebird ImageDock • EdgeTX model images')
        self.resize(1160, 780)
        self.pending = deque()
        self.active = None
        self.completed = 0
        self.failed = 0
        self.total = 0
        self.last_result = None
        self.temp = tempfile.TemporaryDirectory(prefix='BluebirdImageDock_')
        self.profile = QWebEngineProfile(self)  # private, in-memory browser session
        self.profile.downloadRequested.connect(self.on_download)
        self.timeout = QTimer(self)
        self.timeout.setSingleShot(True)
        self.timeout.timeout.connect(self.download_timeout)
        self.advance = QTimer(self)
        self.advance.setSingleShot(True)
        self.advance.timeout.connect(self.next_download)
        self.search_state = None
        self.search_outcome = 'idle'
        self.search_deadline_timer = QTimer(self)
        self.search_deadline_timer.setSingleShot(True)
        self.search_deadline_timer.timeout.connect(self.search_timed_out)
        self.search_poll = QTimer(self)
        self.search_poll.setInterval(300)
        self.search_poll.timeout.connect(self.poll_search)
        self.preview_after = False
        self.preview_timer = QTimer(self)
        self.preview_timer.setSingleShot(True)
        self.preview_timer.timeout.connect(self.preview_selected)
        app_folder = (Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False)
                      else Path(__file__).resolve().parent)
        self.default_output = app_folder / 'downloads' / 'IMAGES'
        self.settings_file = app_folder / 'ImageDock_settings.json'
        self.output = load_destination(self.settings_file, self.default_output)
        root = QWidget(); self.setCentralWidget(root)
        layout = QVBoxLayout(root); layout.setContentsMargins(18, 14, 18, 12)
        title = QLabel('BLUEBIRD  /  ImageDock'); title.setObjectName('title'); layout.addWidget(title)
        info = QLabel('1  Enter a model below     →     2  Pick its color icon     →     3  Download for V16 / TX16S')
        info.setObjectName('subtitle'); layout.addWidget(info)
        # The browser runs behind the app; its view is only an optional fallback.
        self.browser_dialog = QDialog(self)
        self.browser_dialog.setWindowTitle('ImageDock — website fallback')
        self.browser_dialog.resize(1100, 740)
        browser_layout = QVBoxLayout(self.browser_dialog)
        nav = QHBoxLayout(); browser_layout.addLayout(nav)
        self.site = QComboBox(); self.site.addItems(SOURCES)
        self.button(nav, 'Open site', lambda: self.navigate(SOURCES[self.site.currentText()]))
        self.button(nav, '←', lambda: self.web.back())
        self.button(nav, '→', lambda: self.web.forward())
        self.button(nav, 'Reload', lambda: self.web.reload())
        self.address = QLineEdit(); self.address.setPlaceholderText('Paste a model page or direct image URL')
        self.address.returnPressed.connect(lambda: self.navigate(self.address.text()))
        nav.addWidget(self.address, 1)
        self.button(nav, 'Go', lambda: self.navigate(self.address.text()))
        search_row = QHBoxLayout(); layout.addLayout(search_row)
        search_row.addWidget(self.site)
        search_row.addWidget(QLabel('Model:'))
        self.model_search = QLineEdit()
        self.model_search.setPlaceholderText('Example: FMS PA-18, Arrows Viper, Ranger…')
        self.model_search.returnPressed.connect(self.search_models)
        search_row.addWidget(self.model_search, 1)
        self.search_button = self.button(search_row, 'Search color icons', self.search_models)
        self.search_cancel_button = self.button(search_row, 'Cancel search', self.cancel_search)
        self.search_cancel_button.setVisible(False)
        search_row.addWidget(QLabel('V16 / TX16S  •  192 × 114 PNG'))
        split = QSplitter(); layout.addWidget(split, 1)
        self.web = QWebEngineView(self.browser_dialog)
        self.web.setPage(QWebEnginePage(self.profile, self.web))
        browser_layout.addWidget(self.web)
        self.web.urlChanged.connect(lambda u: self.address.setText(u.toString()))
        self.web.loadFinished.connect(self.page_loaded)
        self.scan_button = self.button(browser_layout, 'Collect icons from this page', self.scan)
        self.all_formats = QCheckBox('Include other icon formats / sizes'); browser_layout.addWidget(self.all_formats)
        self.all_formats.stateChanged.connect(lambda _: self.populate())
        results = QWidget(); left = QVBoxLayout(results); split.addWidget(results)
        left.setContentsMargins(0, 0, 12, 0)
        self.count_label = QLabel('Enter a model above. Color icons will appear automatically.'); self.count_label.setWordWrap(True)
        left.addWidget(self.count_label)
        self.search_activity = QProgressBar()
        self.search_activity.setRange(0, 0); self.search_activity.setTextVisible(False)
        self.search_activity.setFixedHeight(8); self.search_activity.setVisible(False)
        left.addWidget(self.search_activity)
        self.result_stack = QStackedWidget(); left.addWidget(self.result_stack, 1)
        self.icons = QListWidget(); self.result_stack.addWidget(self.icons)
        self.empty_state = QWidget(); self.empty_state.setObjectName('emptyCard')
        empty_layout = QVBoxLayout(self.empty_state); empty_layout.setContentsMargins(28, 24, 28, 24)
        empty_layout.addStretch()
        self.empty_title = QLabel('Find your model icon')
        self.empty_title.setTextFormat(Qt.TextFormat.PlainText)
        self.empty_title.setWordWrap(True); self.empty_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        empty_layout.addWidget(self.empty_title)
        self.empty_detail = QLabel('Enter a model name above, then select Search color icons.')
        self.empty_detail.setTextFormat(Qt.TextFormat.PlainText)
        self.empty_detail.setWordWrap(True); self.empty_detail.setAlignment(Qt.AlignmentFlag.AlignCenter)
        empty_layout.addWidget(self.empty_detail)
        empty_actions = QHBoxLayout(); empty_layout.addLayout(empty_actions)
        self.retry_search_button = self.button(empty_actions, 'Retry search', self.search_models)
        self.other_source_button = self.button(empty_actions, 'Try other source', self.try_other_source)
        self.retry_search_button.setVisible(False); self.other_source_button.setVisible(False)
        empty_layout.addStretch(); self.result_stack.addWidget(self.empty_state)
        self.result_stack.setCurrentWidget(self.empty_state)
        self.icons.currentItemChanged.connect(self.show_candidate)
        self.icons.itemDoubleClicked.connect(lambda _: self.download_color())
        side = QWidget(); right = QVBoxLayout(side); split.addWidget(side)
        right.setContentsMargins(12, 0, 0, 0); split.setSizes([560, 520])
        self.selected_label = QLabel('Icon preview'); self.selected_label.setWordWrap(True); right.addWidget(self.selected_label)
        self.preview = QLabel('Search for a model, then select a result.'); self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview.setMinimumSize(380, 270); self.preview.setObjectName('preview'); right.addWidget(self.preview, 1)
        self.preview_button = self.button(right, 'Reload preview', self.preview_selected)
        self.color_button = self.button(right, 'Download icon for V16 / TX16S', self.download_color)
        self.color_button.setStyleSheet('background: #2684d9; font-weight: 700; border-radius: 10px;')
        self.color_button.setEnabled(False)
        self.format = QComboBox(); self.format.addItems(PROFILES); right.addWidget(self.format)
        self.background = QComboBox(); self.background.addItems(['Transparent', 'White', 'Black']); right.addWidget(self.background)
        self.import_button = self.button(right, 'Convert local pictures…', self.import_local)
        self.cancel_button = self.button(right, 'Cancel downloads', self.cancel); self.cancel_button.setEnabled(False)
        target = QHBoxLayout(); layout.addLayout(target)
        target.addWidget(QLabel('Save to:'))
        self.output_label = QLabel(str(self.output)); self.output_label.setWordWrap(True); target.addWidget(self.output_label, 1)
        self.folder_button = self.button(target, 'Choose download folder…', self.choose_folder)
        self.default_folder_button = self.button(target, 'Use app folder', self.use_default_folder)
        self.button(target, 'Open output', self.open_output)
        self.button(target, 'Website fallback', self.browser_dialog.show)
        self.progress = QProgressBar(); self.progress.setVisible(False); layout.addWidget(self.progress)
        self.status = QLabel('Ready. Choose the radio’s IMAGES folder to save directly to its SD card.' if self.output.is_dir() or self.output == self.default_output else
                            'Destination unavailable. Reconnect the radio / SD card or choose another download folder.')
        self.status.setWordWrap(True); layout.addWidget(self.status)
        self.candidates = []
        self.setStyleSheet('''
          QMainWindow, QWidget { background: #11151a; color: #edf3f8; font-family: "Segoe UI"; font-size: 13px; }
          QLabel#title { font-size: 27px; font-weight: 700; color: #78bff1; }
          QLabel#subtitle { color: #9aa9b7; padding-bottom: 9px; }
          QPushButton { background: #222a33; border: 1px solid #35414d; border-radius: 10px; padding: 9px 12px; }
          QPushButton:hover { background: #303c49; } QPushButton:disabled { color: #647688; background: #1b2128; }
          QLineEdit, QComboBox, QListWidget { background: #1b2128; border: 1px solid #35414d; border-radius: 11px; padding: 8px; }
          QListWidget::item { padding: 16px; border-bottom: 1px solid #35414d; }
          QListWidget::item:selected { background: #183754; color: #cde9ff; }
          QLabel#preview { background: #222a33; border: 1px solid #35414d; border-radius: 14px; }
          QWidget#emptyCard { background: #1b2128; border: 1px solid #35414d; border-radius: 14px; }
          QProgressBar { border: 1px solid #35414d; text-align: center; } QProgressBar::chunk { background: #2e9b61; }
        ''')
        if not offline:
            self.navigate(SOURCES['SkyRaccoon'])

    def button(self, parent, label, callback):
        b = QPushButton(label); b.clicked.connect(callback); parent.addWidget(b); return b

    def navigate(self, value):
        value = value.strip()
        if not value: return
        if not urlsplit(value).scheme: value = 'https://' + value
        parts = urlsplit(value)
        if parts.scheme not in ('http', 'https') or not parts.hostname or parts.username or parts.password:
            QMessageBox.warning(self, 'Invalid address', 'Use a public HTTP or HTTPS page or image address.'); return
        self.end_search()
        self.search_outcome = 'idle'
        self.web.setUrl(QUrl(value))
        self.candidates = []; self.populate()

    def page_loaded(self, ok):
        if self.active: return
        if self.search_state:
            self.search_state['loaded'] = ok
            self.status.setText('Searching the website for: ' + self.search_state['query'] if ok else
                                'Waiting for the website to respond…')
            return
        if self.search_outcome in ('empty', 'timeout', 'error', 'cancelled'): return
        self.status.setText('Ready. Enter a model name above and Search color icons.' if ok else
                            'Page could not load. Try the other source, a model link, or local pictures.')
        if ok and '/aircraft/' in self.web.url().path():
            QTimer.singleShot(400, self.scan)

    def search_models(self):
        if self.search_state: return
        if self.active and self.active['task']['mode'] == 'preview': self.cancel()
        if self.active or self.pending: return
        query = self.model_search.text().strip()
        if not query: self.model_search.setFocus(); return
        self.navigate(SOURCES[self.site.currentText()])
        self.all_formats.setChecked(False)
        self.format.setCurrentIndex(0)
        self.search_state = {'query':query[:512], 'token':uuid.uuid4().hex,
                             'started':False, 'loaded':False, 'request_pending':False,
                             'started_at':time.monotonic(), 'deadline':time.monotonic()+SEARCH_TIMEOUT_SECONDS}
        self.search_outcome = 'searching'
        self.set_search_busy(True)
        self.show_search_message('Searching for “' + query + '”…',
            'Looking for V16 / TX16S color icons. This can take up to 10 seconds.', 'searching')
        self.search_deadline_timer.start(SEARCH_TIMEOUT_SECONDS * 1000)
        self.search_poll.start()
        self.status.setText('Searching the website for: ' + query)

    def poll_search(self):
        state = self.search_state
        if not state: self.search_poll.stop(); return
        if time.monotonic() > state['deadline']:
            self.search_timed_out()
            return
        elapsed = min(int(time.monotonic() - state['started_at']), SEARCH_TIMEOUT_SECONDS)
        self.count_label.setText(f'Searching… {elapsed} / {SEARCH_TIMEOUT_SECONDS} seconds')
        token = state['token']
        if not state['loaded'] or state['request_pending']: return
        state['request_pending'] = True
        if not state['started']:
            script = SEARCH_START_JS + '(' + json.dumps(state['query']) + ',' + json.dumps(token) + ')'
            self.web.page().runJavaScript(script, lambda value: self.search_started(token, value))
        else:
            self.web.page().runJavaScript(SEARCH_POLL_JS, lambda value: self.search_ready(token, value))

    def search_started(self, token, value):
        if not self.search_state or self.search_state['token'] != token: return
        self.search_state['request_pending'] = False
        try: result = json.loads(value or '{}')
        except (TypeError, ValueError): return
        if result.get('started'): self.search_state['started'] = True

    def search_ready(self, token, value):
        if not self.search_state or self.search_state['token'] != token: return
        self.search_state['request_pending'] = False
        try: result = json.loads(value or '{}')
        except (TypeError, ValueError): return
        if result.get('token') == token and result.get('ready'):
            self.search_state['request_pending'] = True
            self.web.page().runJavaScript(SCAN_JS, lambda value: self.search_results(token, value))

    def search_results(self, token, value):
        if not self.search_state or self.search_state['token'] != token: return
        query = self.search_state['query']
        try:
            data = json.loads(value)
            if not isinstance(data, list): raise ValueError('Invalid result list')
        except (TypeError, ValueError):
            self.finish_search_message('error', 'Search could not finish',
                'The site returned an unreadable response. Retry or try the other source.')
            return
        self.end_search()
        self.candidates = data; self.populate()
        if self.icons.count():
            self.search_outcome = 'results'
            self.status.setText(f'Search complete: {self.icons.count()} color icons found.')
            self.count_label.setStyleSheet('color: #6ec995;')
            self.icons.setCurrentRow(0)
        else:
            self.finish_search_message('empty', 'No results for “' + query + '”',
                'Check the spelling or try a shorter model name.\n'
                'Leave out the wingspan or extra details, or try a main word such as Cub or Ranger.\n'
                'You can also try the other image source.')

    def set_search_busy(self, busy):
        self.search_activity.setVisible(busy)
        self.search_cancel_button.setVisible(busy)
        self.search_button.setText('Searching…' if busy else 'Search color icons')
        self.search_button.setEnabled(not busy and not bool(self.active or self.pending))
        self.model_search.setEnabled(not busy); self.site.setEnabled(not busy)
        self.import_button.setEnabled(not busy and not bool(self.active or self.pending))
        self.preview_button.setEnabled(not busy and not bool(self.active or self.pending))

    def end_search(self):
        self.search_state = None; self.search_poll.stop(); self.search_deadline_timer.stop()
        self.set_search_busy(False)

    def show_search_message(self, title, detail, kind='idle'):
        color = '#78bff1' if kind == 'searching' else '#e3b66b' if kind in ('empty', 'timeout', 'cancelled') else '#e98a8a' if kind == 'error' else '#edf3f8'
        self.empty_title.setText(title)
        self.empty_title.setStyleSheet('font-size: 20px; font-weight: 700; color: ' + color + '; border: none;')
        self.empty_detail.setText(detail)
        self.empty_detail.setStyleSheet('color: #9aa9b7; border: none; padding: 12px 0;')
        self.result_stack.setCurrentWidget(self.empty_state)
        self.retry_search_button.setVisible(kind not in ('idle', 'searching'))
        self.other_source_button.setVisible(kind not in ('idle', 'searching'))
        self.count_label.setStyleSheet('color: ' + color + ';')

    def finish_search_message(self, outcome, title, detail):
        self.end_search(); self.search_outcome = outcome
        self.show_search_message(title, detail, outcome)
        self.count_label.setText('No results' if outcome == 'empty' else title)
        self.status.setText('Search complete. No matching color icons found.' if outcome == 'empty' else title + '. ' + detail.replace('\n', ' '))
        self.color_button.setEnabled(False)

    def search_timed_out(self):
        if not self.search_state: return
        self.finish_search_message('timeout', 'Search timed out after 10 seconds',
            'The website did not finish responding. Retry the search or try the other source.\n'
            'This does not mean the model is missing from the site.')
        self.web.stop()

    def cancel_search(self):
        if not self.search_state: return
        self.finish_search_message('cancelled', 'Search cancelled',
            'Change the model name or source, then search again.')
        self.web.stop()

    def try_other_source(self):
        if self.search_state: return
        self.site.setCurrentIndex((self.site.currentIndex() + 1) % self.site.count())
        self.search_models()

    def scan(self):
        if self.search_state: return
        self.web.page().runJavaScript(SCAN_JS, self.scan_result)

    def scan_result(self, value):
        try: self.candidates = json.loads(value or '[]')
        except (ValueError, TypeError): self.candidates = []
        self.populate()
        if self.icons.count(): self.icons.setCurrentRow(0)

    def populate(self):
        self.icons.clear()
        data = self.candidates
        # SkyRaccoon/AIR-RC's OpenTX color icons are already 192 × 114 PNGs.
        if not self.all_formats.isChecked():
            preferred = [x for x in data if '/opentx/x10png/' in x['url'].lower()]
            if preferred or any('/airicons/' in x['url'].lower() for x in data): data = preferred
        labels = {}
        for x in data:
            name = x['label'].strip()
            labels[name] = labels.get(name, 0) + 1
            caption = 'Color model icon' if '/opentx/x10png/' in x['url'].lower() else 'Model picture'
            item = QListWidgetItem(name + '\n' + caption + ' · Variant ' + str(labels[name]))
            item.setData(Qt.ItemDataRole.UserRole, x); item.setToolTip(x['url'])
            item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsUserCheckable)
            self.icons.addItem(item)
        self.count_label.setText(f'{len(data)} color icons found. Select one to preview; double-click to download.' if data else
            'No icons found yet. Enter a model above and Search color icons.')
        if data:
            self.result_stack.setCurrentWidget(self.icons)
        elif not self.search_state:
            self.show_search_message('Find your model icon', 'Enter a model name above, then select Search color icons.')
        # Pages opened as individual images have no anchors.
        current = self.web.url().toString()
        if not data and urlsplit(current).path.lower().endswith(('.png', '.bmp', '.jpg', '.jpeg', '.webp')):
            self.candidates = [{'url': current, 'label': Path(urlsplit(current).path).stem, 'kind': 'direct'}]
            self.populate()

    def download_color(self):
        item = self.icons.currentItem()
        if not item:
            QMessageBox.information(self, 'Choose a model', 'Search for a model, then select its icon in the list.'); return
        candidate = item.data(Qt.ItemDataRole.UserRole)
        if not self.destination_ready(): return
        if self.active and self.active['task']['mode'] == 'preview': self.cancel()
        self.preview_timer.stop(); self.preview_after = False
        url = candidate['url']
        host = urlsplit(url).hostname or ''
        if host.endswith(('skyraccoon.com', 'air-rc.com')) and '/opentx/x10png/' not in url.lower():
            QMessageBox.information(self, 'Color icon', 'Choose the OpenTX color PNG version, or turn off other icon formats.'); return
        self.format.setCurrentIndex(0)
        self.begin([dict(candidate, mode='save', **self.options())])

    def show_candidate(self, item, previous):
        self.preview_timer.stop()
        self.preview.clear()
        if item:
            self.color_button.setEnabled(not self.active or self.active['task']['mode'] == 'preview')
            self.selected_label.setText(item.data(Qt.ItemDataRole.UserRole)['label'])
            self.preview.setText('Loading icon preview…')
            self.preview_timer.start(350)
        else:
            self.color_button.setEnabled(False)
            self.selected_label.setText('Icon preview')
            self.preview.setText('Search for a model, then select a result.')

    def options(self):
        return {'profile': self.format.currentText(), 'background': self.background.currentText(),
                'folder': str(self.output), 'require_existing': self.output != self.default_output}

    def preview_selected(self):
        item = self.icons.currentItem()
        if not item: return
        if self.active or self.pending:
            self.preview_after = True
            return
        self.preview_after = False
        self.begin([dict(item.data(Qt.ItemDataRole.UserRole), mode='preview', **self.options())])

    def begin(self, tasks):
        if self.active or self.pending: return
        self.advance.stop()
        self.last_result = None
        self.pending = deque(tasks); self.total = len(tasks); self.completed = self.failed = 0
        self.set_busy(True); self.progress.setRange(0, self.total); self.progress.setValue(0)
        self.progress.setVisible(True); self.next_download()

    def set_busy(self, busy):
        for widget in [self.preview_button, self.search_button,
                       self.folder_button, self.default_folder_button, self.import_button]: widget.setEnabled(not busy)
        self.color_button.setEnabled(bool(self.icons.currentItem()) and
            (not busy or bool(self.active and self.active['task']['mode'] == 'preview')))
        self.cancel_button.setEnabled(busy)

    def next_download(self):
        if not self.pending:
            self.active = None; self.set_busy(False); self.progress.setVisible(False)
            self.status.setText(self.last_result or f'Finished: {self.completed} processed, {self.failed} failed.')
            if self.preview_after:
                self.preview_after = False; self.preview_selected()
            return
        task = self.pending.popleft()
        self.active = {'task': task, 'request': None, 'filename': uuid.uuid4().hex}
        self.set_busy(True)
        self.status.setText('Downloading: ' + task['label'])
        self.timeout.start(60_000)
        self.web.page().download(QUrl(task['url']), 'source_image')

    def on_download(self, request):
        # Only the explicit ImageDock queue is accepted; ordinary page downloads
        # (archives, executables, ads) do not write arbitrary files.
        if (not self.active or self.active['request'] is not None or request.page() != self.web.page()
                or request.url().toString().split('#', 1)[0] !=
                   QUrl(self.active['task']['url']).toString().split('#', 1)[0]):
            request.cancel(); return
        self.active['request'] = request
        request.setDownloadDirectory(self.temp.name)
        request.setDownloadFileName(self.active['filename'])
        request.receivedBytesChanged.connect(self.download_size_changed)
        request.isFinishedChanged.connect(self.download_finished)
        request.accept()

    def download_size_changed(self):
        if (self.active and self.active['request'] == self.sender()
                and self.active['request'].receivedBytes() > MAX_BYTES):
            self.abort_active('Image exceeds the 20 MB limit.')

    def download_timeout(self):
        self.abort_active('Download timed out. Try another source or import a local picture.')

    def abort_active(self, reason):
        active = self.active
        if not active: return
        self.active = None; self.timeout.stop()
        if active['request']: active['request'].cancel()
        self.failed += 1; self.status.setText(reason)
        self.last_result = reason
        if active['task']['mode'] == 'preview': self.preview.setText('Preview unavailable. Try another result or source.')
        self.progress.setValue(self.completed + self.failed)
        self.advance.start(300)

    def download_finished(self):
        if not self.active: return
        request = self.active['request']
        if not request or request != self.sender() or not request.isFinished(): return
        task = self.active['task']; self.active = None; self.timeout.stop()
        try:
            if request.state() != QWebEngineDownloadRequest.DownloadState.DownloadCompleted:
                raise ValueError('Download failed: ' + request.interruptReasonString())
            src = Path(request.downloadDirectory()) / request.downloadFileName()
            if src.stat().st_size > MAX_BYTES: raise ValueError('Image exceeds the 20 MB limit.')
            data, extension = convert_image(src.read_bytes(), task['profile'], task['background'])
            pix = QPixmap(); pix.loadFromData(data)
            selected = self.icons.currentItem()
            if selected and selected.data(Qt.ItemDataRole.UserRole)['url'] == task['url']:
                self.preview.setPixmap(pix.scaled(480, 285, Qt.AspectRatioMode.KeepAspectRatio,
                                                 Qt.TransformationMode.SmoothTransformation))
            if task['mode'] == 'save':
                saved = save_unique(task['folder'], task['label'], data, extension,
                                    require_existing=task['require_existing'])
                self.last_result = 'Icon saved: ' + str(saved)
                try: record_save(task['folder'], saved.name, task['label'], task['url'], task['profile'])
                except OSError as err: QMessageBox.warning(self, 'Source map', f'Image saved, but source map failed: {err}')
            else: self.last_result = 'Preview ready. Download icon to save it to the selected folder.'
            self.completed += 1
        except Exception as err:
            self.failed += 1; self.last_result = 'Could not load icon: ' + str(err)
            if task['mode'] == 'preview': self.preview.setText('Preview unavailable. Try another result or source.')
        finally:
            (Path(request.downloadDirectory()) / request.downloadFileName()).unlink(missing_ok=True)
        self.progress.setValue(self.completed + self.failed)
        self.advance.start(400)

    def cancel(self):
        self.preview_timer.stop(); self.preview_after = False
        self.end_search()
        self.advance.stop()
        self.pending.clear(); active = self.active; self.active = None; self.timeout.stop()
        if active and active['request']: active['request'].cancel()
        self.set_busy(False); self.progress.setVisible(False)
        self.status.setText('Cancelled. Already saved images remain in the output folder.')

    def import_local(self):
        if not self.destination_ready(): return
        paths, _ = QFileDialog.getOpenFileNames(self, 'Choose pictures', '', 'Pictures (*.png *.bmp *.jpg *.jpeg *.webp)')
        errors = []; count = 0
        for path in paths:
            try:
                src = Path(path)
                if src.stat().st_size > MAX_BYTES: raise ValueError('Image exceeds the 20 MB limit.')
                data, extension = convert_image(src.read_bytes(), self.format.currentText(), self.background.currentText())
                saved = save_unique(self.output, src.stem, data, extension,
                                    require_existing=self.output != self.default_output); count += 1
                record_save(self.output, saved.name, src.stem, str(src), self.format.currentText())
            except Exception as err: errors.append(Path(path).name + ': ' + str(err))
        self.status.setText(f'{count} local images saved to {self.output}.')
        if errors: QMessageBox.warning(self, 'Import results', '\n'.join(errors[:12]))

    def choose_folder(self):
        folder = QFileDialog.getExistingDirectory(self, 'Choose download destination — select IMAGES on your radio / SD card',
                                                  str(self.output if self.output.is_dir() else self.default_output.parent))
        if not folder: return
        self.set_destination(Path(folder).resolve())

    def use_default_folder(self):
        self.set_destination(self.default_output)

    def set_destination(self, folder):
        self.output = folder
        self.output_label.setText(str(self.output))
        self.output_label.setToolTip(str(self.output))
        try:
            store_destination(self.settings_file, None if self.output == self.default_output else self.output)
            self.status.setText('Download destination saved: ' + str(self.output))
        except OSError as err:
            self.status.setText('Destination selected for this session; could not remember it: ' + str(err))

    def destination_ready(self):
        try:
            if self.output != self.default_output: check_destination(self.output)
            return True
        except OSError as err:
            self.status.setText(str(err))
            QMessageBox.warning(self, 'Download destination unavailable', str(err))
            return False

    def open_output(self):
        if not self.destination_ready(): return
        try:
            self.output.mkdir(parents=True, exist_ok=True)
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.output)))
        except OSError as err: QMessageBox.warning(self, 'Output folder', str(err))

    def closeEvent(self, event):
        self.cancel()
        old_page = self.web.page()
        self.web.setPage(QWebEnginePage(self.web))
        old_page.deleteLater()
        self.temp.cleanup()
        super().closeEvent(event)


def main():
    app = QApplication(sys.argv)
    app.setApplicationName('Bluebird ImageDock')
    window = Dock(offline='--offline' in sys.argv)
    window.show()
    return app.exec()


if __name__ == '__main__':
    sys.exit(main())
