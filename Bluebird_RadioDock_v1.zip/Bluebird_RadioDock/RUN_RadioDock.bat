@echo off
cd /d "%~dp0"
python Bluebird_RadioDock.py
if errorlevel 1 pause
