"""Qt interface for LuaDock's existing catalog and package engine."""
import threading
from pathlib import Path
from PySide6.QtCore import Qt, QObject, Signal, QTimer, QUrl
from PySide6.QtGui import QPixmap, QDesktopServices
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QLineEdit, QComboBox, QSplitter, QListWidget, QListWidgetItem, QFileDialog,
    QMessageBox, QProgressBar, QScrollArea, QAbstractItemView, QTextEdit)
import luadock_engine as engine
from imagedock_core import load_destination, store_destination, check_destination


class Events(QObject):
    done = Signal(str, int, object)
    progress = Signal(str)


def button(layout, text, callback):
    control = QPushButton(text)
    control.clicked.connect(callback)
    layout.addWidget(control)
    return control


class LuaPanel(QWidget):
    def __init__(self, offline=False):
        super().__init__()
        self.items = []
        self.selected_ids = set()
        self.current = None
        self.preview_index = 0
        self.preview_generation = 0
        self.catalog_generation = 0
        self.catalog_busy = False
        self.download_busy = False
        self.closed = False
        self.stop = threading.Event()
        self.settings = engine.program_directory() / 'LuaDock_settings.json'
        self.default_output = engine.program_directory() / 'downloads' / 'LUA'
        self.output = load_destination(self.settings, self.default_output)
        self.events = Events(self)
        self.events.done.connect(self.finished)
        self.events.progress.connect(self.show_progress)
        layout = QVBoxLayout(self); layout.setContentsMargins(18,14,18,12)
        heading = QLabel('Lua tools & add-ons'); heading.setObjectName('title'); layout.addWidget(heading)
        subtitle = QLabel('Scripts, widgets, themes and RGB gimbal tools • Official EdgeTX catalog')
        subtitle.setObjectName('subtitle'); layout.addWidget(subtitle)
        controls = QHBoxLayout(); layout.addLayout(controls)
        self.search = QLineEdit(); self.search.setPlaceholderText('Find a script, widget, theme or LED tool…')
        self.search.setClearButtonEnabled(True); controls.addWidget(self.search,1)
        self.compatibility = QComboBox()
        self.compatibility.addItem('V16 / TX16S family (Color)', 'color')
        for label, tag in engine.RADIO_PROFILES:
            self.compatibility.addItem(label,tag)
        controls.addWidget(self.compatibility)
        self.refresh_button = button(controls,'Refresh catalog',self.refresh)
        self.activity = QProgressBar(); self.activity.setRange(0,0)
        self.activity.setFixedHeight(8); self.activity.hide(); layout.addWidget(self.activity)
        split=QSplitter(); layout.addWidget(split,1)
        self.categories=QListWidget(); self.categories.setMinimumWidth(195); self.categories.setMaximumWidth(225); self.categories.setWordWrap(True); split.addWidget(self.categories)
        results=QWidget(); left=QVBoxLayout(results); left.setContentsMargins(6,0,6,0); split.addWidget(results)
        self.count=QLabel('No catalog loaded'); left.addWidget(self.count)
        self.results=QListWidget(); self.results.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        left.addWidget(self.results,1)
        actions=QHBoxLayout(); left.addLayout(actions)
        button(actions,'Select visible',self.select_visible)
        button(actions,'Clear selection',self.clear_selection)
        right=QWidget(); details=QVBoxLayout(right); details.setContentsMargins(10,0,0,0); split.addWidget(right)
        self.name=QLabel('Choose an add-on'); self.name.setObjectName('detailName'); self.name.setWordWrap(True); details.addWidget(self.name)
        self.preview=QLabel('Screenshots appear here'); self.preview.setObjectName('preview')
        self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter); self.preview.setMinimumSize(280,195)
        details.addWidget(self.preview,1)
        previews=QHBoxLayout(); details.addLayout(previews)
        self.back=button(previews,'‹',lambda:self.change_preview(-1))
        self.preview_count=QLabel('No screenshots'); self.preview_count.setAlignment(Qt.AlignmentFlag.AlignCenter); previews.addWidget(self.preview_count,1)
        self.next=button(previews,'›',lambda:self.change_preview(1))
        self.description=QTextEdit(); self.description.setReadOnly(True); self.description.setMinimumHeight(120)
        details.addWidget(self.description,1)
        self.source_button=button(details,'Open publisher page',self.open_source)
        self.source_button.setEnabled(False)
        split.setSizes([190,490,400])
        job=QHBoxLayout(); layout.addLayout(job)
        self.selection_label=QLabel('0 selected'); job.addWidget(self.selection_label,1)
        self.download_button=button(job,'Download selected',self.download_selected)
        self.download_button.setObjectName('primary')
        self.cancel_button=button(job,'Stop after current file',self.cancel_downloads); self.cancel_button.hide()
        target=QHBoxLayout(); layout.addLayout(target)
        target.addWidget(QLabel('Save to:'))
        self.destination=QLabel(str(self.output)); self.destination.setWordWrap(True); target.addWidget(self.destination,1)
        self.folder_button=button(target,'Choose download folder…',self.choose_folder)
        self.default_button=button(target,'Use app folder',lambda:self.set_destination(self.default_output))
        button(target,'Open output',self.open_output)
        self.status=QLabel('Ready. Refresh the catalog to find add-ons.'); self.status.setWordWrap(True); layout.addWidget(self.status)
        self.search.textChanged.connect(self.apply_filters)
        self.compatibility.currentIndexChanged.connect(self.rebuild_categories)
        self.categories.currentRowChanged.connect(self.apply_filters)
        self.results.currentItemChanged.connect(self.show_detail)
        self.results.itemSelectionChanged.connect(self.selection_changed)
        self.preview_delay=QTimer(self); self.preview_delay.setSingleShot(True)
        self.preview_delay.timeout.connect(self.load_preview)
        self.update_controls()
        try:
            self.items,_,stamp=engine.load_catalog_cache()
            self.rebuild_categories()
            self.status.setText('Saved catalog loaded • '+stamp)
        except (OSError,ValueError,KeyError):
            self.rebuild_categories()
        if not offline: QTimer.singleShot(200,self.refresh)

    def worker(self, kind, generation, operation):
        def run():
            try: result=(True,operation())
            except Exception as exc: result=(False,str(exc))
            if not self.closed: self.events.done.emit(kind,generation,result)
        threading.Thread(target=run,daemon=True,name='RadioDock-'+kind).start()

    def refresh(self):
        if self.catalog_busy or self.download_busy or self.closed: return
        self.catalog_busy=True; self.catalog_generation+=1
        self.status.setText('Refreshing catalog, themes and LED tools…')
        self.update_controls()
        def fetch():
            items,source=engine.fetch_catalog()
            warning=''
            try: engine.save_catalog_cache(items,source)
            except OSError as exc: warning=' • Cache could not be saved: '+str(exc)
            return items,warning
        self.worker('catalog',self.catalog_generation,fetch)

    def compatible(self):
        tag=self.compatibility.currentData()
        return [i for i in self.items if tag=='all' or (tag=='color' and i.is_color) or
                (tag=='black-and-white' and i.is_black_and_white)]

    def rebuild_categories(self,*_):
        old=self.categories.currentItem()
        previous=old.data(Qt.ItemDataRole.UserRole) if old else 'All Add-ons'
        self.categories.blockSignals(True); self.categories.clear()
        compatible=self.compatible(); counts={}
        for i in compatible: counts[i.category]=counts.get(i.category,0)+1
        names=['All Add-ons']+sorted(counts,key=engine.category_sort_key)
        for name in names:
            row=QListWidgetItem(f'{name}   {len(compatible) if name=="All Add-ons" else counts[name]}')
            row.setData(Qt.ItemDataRole.UserRole,name); self.categories.addItem(row)
        self.categories.setCurrentRow(names.index(previous) if previous in names else 0)
        self.categories.blockSignals(False); self.apply_filters()

    def apply_filters(self,*_):
        category=self.categories.currentItem()
        category=category.data(Qt.ItemDataRole.UserRole) if category else 'All Add-ons'
        query=self.search.text().strip().casefold()
        filtered=[i for i in self.compatible() if (category=='All Add-ons' or i.category==category) and
            (not query or query in ' '.join((i.name,i.description,i.category,*i.tags)).casefold())]
        current_id=self.current.item_id if self.current else None
        self.results.blockSignals(True); self.results.clear()
        for i in filtered:
            row=QListWidgetItem(f'{i.name}\n{i.category}  •  {i.source_kind}')
            row.setData(Qt.ItemDataRole.UserRole,i); self.results.addItem(row)
            row.setToolTip(i.description)
            row.setSelected(i.item_id in self.selected_ids)
        self.results.blockSignals(False)
        self.count.setText(f'{len(filtered)} add-ons' if filtered else 'No results. Check spelling or clear a filter.')
        match=next((n for n,i in enumerate(filtered) if i.item_id==current_id),0)
        # Preserve selected downloads while changing which item is previewed.
        if filtered:
            from PySide6.QtCore import QItemSelectionModel
            self.results.setCurrentItem(self.results.item(match),QItemSelectionModel.SelectionFlag.NoUpdate)
            self.show_detail(self.results.item(match),None)
        else: self.show_detail(None,None)
        self.selection_label.setText(f'{len(self.selected_ids)} selected'); self.update_controls()

    def selection_changed(self):
        visible={self.results.item(n).data(Qt.ItemDataRole.UserRole).item_id for n in range(self.results.count())}
        checked={r.data(Qt.ItemDataRole.UserRole).item_id for r in self.results.selectedItems()}
        self.selected_ids=(self.selected_ids-visible)|checked
        self.selection_label.setText(f'{len(self.selected_ids)} selected'); self.update_controls()

    def select_visible(self): self.results.selectAll()

    def clear_selection(self):
        self.selected_ids.clear(); self.results.clearSelection()
        self.selection_label.setText('0 selected'); self.update_controls()

    def show_detail(self,row,_=None):
        self.preview_generation+=1; self.preview_delay.stop()
        self.current=row.data(Qt.ItemDataRole.UserRole) if row else None
        self.preview_index=0; self.preview.clear()
        i=self.current
        self.name.setText(i.name if i else 'Choose an add-on')
        self.description.setPlainText((i.description+'\n\nCompatibility: '+', '.join(i.tags)+'\n\n'+i.source_kind) if i else '')
        self.source_button.setEnabled(bool(i and i.info_url))
        self.preview.setText('Loading screenshot…' if i and i.images else 'No screenshot supplied by publisher')
        self.back.setEnabled(False); self.next.setEnabled(False)
        self.preview_count.setText('No screenshots')
        if i and i.images: self.preview_delay.start(150)

    def change_preview(self,change):
        images=[p for p in self.current.images if engine.preview_url(p)] if self.current else []
        if images:
            self.preview_index=(self.preview_index+change)%len(images)
            self.load_preview()

    def load_preview(self):
        self.preview_generation+=1; generation=self.preview_generation
        images=[p for p in self.current.images if engine.preview_url(p)] if self.current else []
        self.back.setEnabled(len(images)>1); self.next.setEnabled(len(images)>1)
        if not images:
            self.preview.setText('No supported screenshot supplied'); return
        self.preview.clear(); self.preview.setText('Loading screenshot…')
        self.preview_count.setText(f'{self.preview_index+1} / {len(images)}')
        path=images[self.preview_index]
        self.worker('preview',generation,lambda:engine.preview_bytes(path))

    def update_controls(self):
        busy=self.catalog_busy or self.download_busy
        self.refresh_button.setEnabled(not busy)
        self.download_button.setEnabled(not busy and bool(self.selected_ids))
        self.folder_button.setEnabled(not self.download_busy); self.default_button.setEnabled(not self.download_busy)
        self.cancel_button.setVisible(self.download_busy)
        self.cancel_button.setEnabled(not self.stop.is_set())
        self.activity.setVisible(busy)

    def set_destination(self,folder):
        self.output=Path(folder); self.destination.setText(str(self.output))
        self.destination.setToolTip(str(self.output))
        try:
            store_destination(self.settings,None if self.output==self.default_output else self.output)
            self.status.setText('Download destination saved: '+str(self.output))
        except OSError as exc: self.status.setText('Folder selected for this session: '+str(exc))

    def choose_folder(self):
        folder=QFileDialog.getExistingDirectory(self,'Choose Lua package download folder',str(self.output))
        if folder: self.set_destination(Path(folder).resolve())

    def destination_ready(self):
        try:
            if self.output!=self.default_output: check_destination(self.output)
            else: self.output.mkdir(parents=True,exist_ok=True)
            return True
        except OSError as exc:
            self.status.setText(str(exc)); QMessageBox.warning(self,'Destination unavailable',str(exc)); return False

    def open_output(self):
        if self.destination_ready(): QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.output)))

    def open_source(self):
        if self.current and self.current.info_url: QDesktopServices.openUrl(QUrl(self.current.info_url))

    def download_selected(self):
        if self.catalog_busy or self.download_busy or not self.destination_ready(): return
        items=[i for i in self.items if i.item_id in self.selected_ids]
        duplicates=[i.name for i in items if engine.existing_downloads(i,self.output)]
        if duplicates and QMessageBox.question(self,'Already downloaded',
            'Save another copy of these existing downloads?\n\n'+'\n'.join(duplicates),
            QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,QMessageBox.StandardButton.No)!=QMessageBox.StandardButton.Yes:
            items=[i for i in items if i.name not in duplicates]
        if not items: return
        self.download_busy=True; self.stop.clear(); self.update_controls()
        destination=self.output
        def download():
            results=[]
            for n,i in enumerate(items,1):
                if self.stop.is_set(): break
                def progress(done,total,item=i,position=n):
                    if not self.closed:
                        self.events.progress.emit(f'{position}/{len(items)} • {item.name} • '+engine.human_bytes(done)+
                                                  (' / '+engine.human_bytes(total) if total else ''))
                if not self.closed: self.events.progress.emit(f'{n}/{len(items)} • Downloading {i.name}…')
                results.append(engine.download_catalog_item(i,destination,progress))
            manifest=None; warning=''
            if results:
                try: manifest=engine.write_manifest(results,destination)
                except OSError as exc: warning='Report could not be saved: '+str(exc)
            return results,manifest,len(items)-len(results),warning
        self.worker('download',0,download)

    def cancel_downloads(self):
        self.stop.set(); self.cancel_button.setEnabled(False)
        self.status.setText('Stopping after the current file finishes…')

    def show_progress(self,message):
        if not self.closed: self.status.setText(message)

    def finished(self,kind,generation,payload):
        if self.closed: return
        ok,result=payload
        if kind=='preview':
            if generation!=self.preview_generation: return
            pixmap=QPixmap()
            if ok and pixmap.loadFromData(result):
                self.preview.setPixmap(pixmap.scaled(self.preview.size(),Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
            else: self.preview.setText('Screenshot unavailable. Open the publisher page for details.')
        elif kind=='catalog':
            if generation!=self.catalog_generation: return
            self.catalog_busy=False
            if ok:
                self.items,warning=result
                self.selected_ids.intersection_update(i.item_id for i in self.items)
                self.rebuild_categories(); self.status.setText(f'Catalog ready • {len(self.items)} add-ons'+warning)
            else:
                self.status.setText('Catalog refresh failed. '+('Saved catalog is still available. ' if self.items else '')+'Check the connection and retry.')
                self.status.setToolTip(result)
            self.update_controls()
        elif kind=='download':
            self.download_busy=False; self.stop.clear()
            if not ok: self.status.setText('Download failed: '+result)
            else:
                results,manifest,remaining,warning=result
                downloaded=sum(r.status=='downloaded' for r in results)
                links=sum(r.status=='manual' for r in results)
                failures=[r for r in results if r.status=='failed']
                for r in results:
                    if r.status in ('downloaded','manual'): self.selected_ids.discard(r.item.item_id)
                self.apply_filters()
                self.status.setText(f'Finished • {downloaded} packages • {links} publisher links • {len(failures)} failed • {remaining} cancelled'+
                                    (' • '+warning if warning else ''))
                if failures: QMessageBox.warning(self,'Some downloads failed','\n'.join(r.item.name+': '+r.detail for r in failures))
            self.update_controls()

    def shutdown(self):
        self.closed=True; self.stop.set(); self.preview_delay.stop(); self.preview_generation+=1
