import sys,io,time,threading,tempfile,json
from pathlib import Path
from http.server import BaseHTTPRequestHandler,HTTPServer
sys.path.insert(0,str(Path(__file__).resolve().parent))
from PIL import Image,ImageDraw
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication,QMessageBox
from PySide6.QtWebEngineCore import QWebEngineUrlRequestInterceptor
import Bluebird_ImageDock as module
img=Image.new('RGBA',(192,114),(0,0,0,0));d=ImageDraw.Draw(img)
d.polygon([(15,62),(165,58),(184,47),(180,65),(157,72),(20,71)],fill='#f0bb44')
d.polygon([(75,62),(94,28),(123,28),(110,64)],fill='#f0bb44')
d.polygon([(157,59),(162,39),(173,39),(170,59)],fill='#dfaa30')
d.line([(46,68),(46,80),(78,80)],fill='#d7e0ea',width=2)
buf=io.BytesIO();img.save(buf,'PNG');png=buf.getvalue()
html='''<html><body><form role="search"><input class="ais-SearchBox-input" type="search"><button type="submit">Search</button><span class="ais-SearchBox-loadingIndicator" hidden></span></form><div class="ais-Hits"><ul><li class="ais-Hits-item">Default <a href="/assets/images/airicons/opentx/x10png/default.png">Horus</a></li></ul></div><script>
const input=document.querySelector('input');const hits=document.querySelector('.ais-Hits');
input.addEventListener('input',()=>{let query=input.value;if(query==='stall') return;setTimeout(()=>{hits.innerHTML=query==='missing'?'<p>No results</p>':'<ul><li class="ais-Hits-item">PA-18 Super Cub FMS <a href="/assets/images/airicons/opentx/x10png/one.png">Horus</a><a href="/assets/images/airicons/opentx/bw/one.bmp">X9</a></li><li class="ais-Hits-item">PA-18 Super Cub FMS <a href="/assets/images/airicons/opentx/x10png/two.png">Horus</a></li></ul>';},180);});
document.querySelector('form').addEventListener('submit',e=>e.preventDefault());</script></body></html>'''.encode()
requests=[]
class Handler(BaseHTTPRequestHandler):
 def do_GET(self):
  requests.append(self.path); self.send_response(200);self.send_header('Content-Type','image/png' if self.path.endswith('.png') else 'text/html');self.end_headers();self.wfile.write(png if self.path.endswith('.png') else html)
 def log_message(self,*a):pass
server=HTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
base=f'http://127.0.0.1:{server.server_port}/';module.SOURCES['SkyRaccoon']=base
class LocalOnly(QWebEngineUrlRequestInterceptor):
 def interceptRequest(self,info):
  if info.requestUrl().host() not in ('127.0.0.1',''):info.block(True)
from Bluebird_RadioDock import RadioDock
app=QApplication([]);combined=RadioDock(offline=True);combined.switch(1);window=combined.images;guard=LocalOnly(window);window.profile.setUrlRequestInterceptor(guard)
errors=[];QMessageBox.warning=lambda *a: errors.append(a[-1]);combined.show()
root=tempfile.TemporaryDirectory();window.settings_file=Path(root.name)/'settings.json'
destination=Path(root.name)/'radio'/'Pictures';destination.mkdir(parents=True)
original_picker=module.QFileDialog.getExistingDirectory
module.QFileDialog.getExistingDirectory=lambda *a: str(destination)
window.choose_folder()
assert window.output==destination and window.output_label.text()==str(destination)
assert module.load_destination(window.settings_file,window.default_output)==destination
module.QFileDialog.getExistingDirectory=lambda *a: ''
window.choose_folder();assert window.output==destination
window.use_default_folder();assert window.output==window.default_output
assert module.load_destination(window.settings_file,Path(root.name)/'moved')==Path(root.name)/'moved'
window.set_destination(destination)
module.QFileDialog.getExistingDirectory=original_picker
window.model_search.setText('PA-18');window.search_models();stage=0;started=time.monotonic();timeout_started=0;stale_token=None
def step():
 global stage,timeout_started,stale_token
 try:
  if time.monotonic()-started>45:raise AssertionError('timeout '+str(stage))
  if stage==0 and window.icons.count()==2 and window.preview.pixmap() and not window.preview.pixmap().isNull() and not window.active:
   assert not window.browser_dialog.isVisible()
   assert 'Default' not in window.icons.item(0).text()
   assert all(not(window.icons.item(i).flags() & module.Qt.ItemFlag.ItemIsUserCheckable) for i in range(2))
   window.download_color();stage=1
  elif stage==1 and window.completed==1 and not window.active and window.color_button.isEnabled() and list(window.output.glob('*.png')):
   assert len(list(window.output.glob('*.png')))==1
   assert not (destination/'IMAGES').exists()
   with Image.open(next(window.output.glob('*.png'))) as saved:assert saved.size==(192,114)
   window.status.setText('Icon saved beside the app • V16 / TX16S color PNG')
   window.model_search.setText('missing');window.search_models();stage=2
  elif stage==2 and not window.search_state and window.icons.count()==0:
   assert not window.color_button.isEnabled()
   assert not window.browser_dialog.isVisible()
   assert not errors,errors
   assert window.search_outcome=='empty'
   assert 'No results' in window.empty_title.text()
   assert 'spelling' in window.empty_detail.text()
   assert window.retry_search_button.isVisible()
   assert window.search_button.isEnabled() and window.model_search.isEnabled()
   assert not window.search_activity.isVisible()
   window.model_search.setText('stall');window.search_models()
   stale_token=window.search_state['token'];timeout_started=time.monotonic()
   assert window.search_activity.isVisible()
   assert not window.search_button.isEnabled() and not window.model_search.isEnabled()
   assert window.search_cancel_button.isVisible()
   assert window.result_stack.currentWidget()==window.empty_state
   stage=3
  elif stage==3 and not window.search_state:
   elapsed=time.monotonic()-timeout_started
   assert 9.5<=elapsed<12,elapsed
   assert window.search_outcome=='timeout'
   assert '10 seconds' in window.empty_title.text()
   assert not window.search_activity.isVisible()
   assert window.search_button.isEnabled() and window.model_search.isEnabled()
   window.search_results(stale_token,json.dumps([{'url':base+'late.png','label':'Late icon','kind':'link'}]))
   assert window.icons.count()==0 and window.search_outcome=='timeout'
   window.model_search.setText('PA-18');window.search_models();window.cancel_search()
   assert window.search_outcome=='cancelled' and not window.search_state
   assert not window.search_activity.isVisible() and window.search_button.isEnabled()
   window.retry_search_button.click();stage=4
  elif stage==4 and window.icons.count()==2 and not window.search_state and window.preview.pixmap() and not window.active:
   assert window.search_outcome=='results'
   assert not window.search_activity.isVisible()
   assert not window.browser_dialog.isVisible()
   assert not errors,errors
   print('GUI PASS: exact destination picker, remembered folder, cancel picker, reset portable default, direct save; search/preview, no-results, 10-second timeout, cancel/retry',flush=True)
   timer.stop();combined.close();server.shutdown();root.cleanup();app.quit()
 except Exception as e:
  import traceback;traceback.print_exc();print('GUI FAIL:',repr(e),'stage',stage,flush=True);timer.stop();combined.close();app.exit(1)
timer=QTimer();timer.timeout.connect(step);timer.start(100)
sys.exit(app.exec())
