@echo off
setlocal
cd /d "%~dp0"
echo =====================================================
echo   Bluebird RadioDock - Windows EXE Builder
echo =====================================================
echo Builds in a short temporary folder to avoid long-path errors.
echo First build needs internet and Python 3.10 or newer.
echo.
where py >nul 2>nul
if errorlevel 1 goto UsePython
py -3 build_windows.py
goto CheckBuild
:UsePython
python build_windows.py
:CheckBuild
if errorlevel 1 goto Failed
pause
exit /b 0
:Failed
echo.
echo Build failed. The specific error is shown above.
echo No changes to Windows long-path settings are required.
pause
exit /b 1
